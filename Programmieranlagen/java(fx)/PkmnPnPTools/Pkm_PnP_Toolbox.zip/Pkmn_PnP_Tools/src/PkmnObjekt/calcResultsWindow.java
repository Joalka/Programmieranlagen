package PkmnObjekt;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import BattletoolsDM.Daten_Kampfteilnehmer;
import javafx.geometry.*;

public class calcResultsWindow {
	
		


	
		public static boolean calcResults() {
			
			
	 
			Stage ResultsWindow = new Stage ();
			
			//Diese Klasse sperrt das Parent-window
			ResultsWindow.initModality(Modality.APPLICATION_MODAL);	
			ResultsWindow.setTitle("Damage Results");
			ResultsWindow.setMinWidth(100);
			ResultsWindow.setMinHeight(100);
			
			GridPane resultsgrid = new GridPane();
			resultsgrid.setPadding(new Insets(0,0,0,0));
			resultsgrid.setVgap(15);
			resultsgrid.setHgap(15);
			
			Label nametxt = new Label ("Name:");
			Label Defmulttxt = new Label ("Dmg mult:");
			Label weaknessResistance = new Label ("Type mult:");
			setIntoGridVertikal(nametxt, Defmulttxt, weaknessResistance, 0, 1, 0);
			Label Damage = new Label ("Dmg");
			GridPane.setConstraints(Damage, 4, 0);
			
			double [] Typemults = new double [PickDefendentWindow.Verteidiger.length];

			
			
			
			Label[] nameLabel	= new Label[PickDefendentWindow.Verteidiger.length];
			TextField[]dmgMults	= new TextField[PickDefendentWindow.Verteidiger.length];
			Label[] TypeMultLabels 	= new Label[PickDefendentWindow.Verteidiger.length];
			Label[] dmgResults 	= new Label[PickDefendentWindow.Verteidiger.length];
						
			for (int i = 0; i < PickDefendentWindow.Verteidiger.length; i++) {
				nameLabel[i] = new Label("" + PickDefendentWindow.Verteidiger[i].getName());
				System.out.println("nameLabel"+i+"wurde belegt mit "+nameLabel[i].getText());
				GridPane.setConstraints(nameLabel[i], 0, i+1);
				resultsgrid.getChildren().add(nameLabel[i]);
				
				dmgMults[i]=new TextField();
				dmgMults[i].setText("1.0");
				GridPane.setConstraints(dmgMults[i], 1, i+1);
				resultsgrid.getChildren().add(dmgMults[i]);
				
				Typemults[i] = 1;
				Typemults[i] *= Typenwechselwirkung(AttackCalcGUI.AtkType.getValue(),PickDefendentWindow.Verteidiger[i].getType1()) ;
				Typemults[i] *= Typenwechselwirkung(AttackCalcGUI.AtkType.getValue(),PickDefendentWindow.Verteidiger[i].getType2()) ;
				
				TypeMultLabels[i]= new Label(""+Typemults[i]);
				GridPane.setConstraints(TypeMultLabels[i], 2, i+1);
				resultsgrid.getChildren().add(TypeMultLabels[i]);
				
				
				dmgResults[i]=new Label(""+calc_dmg(PickAttackerWindow.Attacker.getAtk(), PickAttackerWindow.Attacker.getSAtk(), Integer.parseInt(AttackCalcGUI.nbPower.getText())
						, PickDefendentWindow.Verteidiger[i].getDef(), PickDefendentWindow.Verteidiger[i].getSDef(), Double.parseDouble(AttackCalcGUI.nbAtkMult.getText()),Double.parseDouble(dmgMults[i].getText()),Typemults[i], AttackCalcGUI.SAtk.isSelected()));
				GridPane.setConstraints(dmgResults[i], 4, i+1);
				resultsgrid.getChildren().add(dmgResults[i]);
			}

			Button ConfirmButton = new Button("Calculate");
			GridPane.setConstraints(ConfirmButton, 2, 4+PickDefendentWindow.Verteidiger.length);
			ConfirmButton.setOnAction(e->{
				for (int i = 0; i<PickDefendentWindow.Verteidiger.length;i++) {
					dmgResults[i].setText(""+calc_dmg(PickAttackerWindow.Attacker.getAtk(), PickAttackerWindow.Attacker.getSAtk(), Integer.parseInt(AttackCalcGUI.nbPower.getText())
							, PickDefendentWindow.Verteidiger[i].getDef(), PickDefendentWindow.Verteidiger[i].getSDef(), Double.parseDouble(AttackCalcGUI.nbAtkMult.getText()),Double.parseDouble(dmgMults[i].getText()),Typemults[i], AttackCalcGUI.SAtk.isSelected()));
				}

			});
			
			resultsgrid.getChildren().addAll(nametxt,Defmulttxt,weaknessResistance,Damage,ConfirmButton);
					

			
			Scene pickDefendent = new Scene(resultsgrid,500,300);
			ResultsWindow.setScene(pickDefendent);
			ResultsWindow.showAndWait();
		
			return true;
			
		
		}
		public static void setIntoGridVertikal (Label l1, Label l2, Label l3, 
				int start, int every, int YAxis) {
			Label [] list = {l1,l2,l3};
			int position = start;
			
			for (int i = 0; i<list.length; i++ ) {
				GridPane.setConstraints(list[i], position, YAxis);
				position += every;
			}
		}
		public static int calc_dmg (int Atk, int SAtk, int power, int Def, int SDef, double Atkmult, double Dmgmult, double Typenwechselwirkung, boolean Spezial){
			int dmg;
			double step1;
			if(!Spezial) {
			step1 = (double)Atk/Def;
			} else step1 = (double)SAtk/SDef;
			return dmg = (int)Math.round(step1*power*Atkmult*Dmgmult*Typenwechselwirkung);
		}
		public static double Typenwechselwirkung(String Angreifertyp, String Verteidigertyp) {
			double mult = 1;
			switch(Angreifertyp) {
			case"Normal":{
				switch (Verteidigertyp){
				case "Gestein":		mult /= 2;	break;
				case "Stahl":		mult /= 2;	break;	
				default: break;
				}
			}break;
			case"Kampf":{
				switch (Verteidigertyp){
				case "Normal":		mult *= 2;	break;
				case "Gestein":		mult *= 2;	break;
				case "Stahl":		mult *= 2;	break;	
				case "Eis":			mult *= 2;	break;
				case "Unlicht":		mult *= 2;	break;	
				
				case "Flug":		mult /= 2;	break;
				case "Gift":		mult /= 2;	break;
				case "Käfer":		mult /= 2;	break;	
				case "Psycho":		mult /= 2;	break;
				case "Fee":			mult /= 2;	break;	
				default: break;
				}
			}break;
			case"Flug":{
				switch (Verteidigertyp){
				case "Kampf":		mult *= 2;	break;
				case "Käfer":		mult *= 2;	break;
				case "Pflanze":		mult *= 2;	break;		
				
				case "Gestein":		mult /= 2;	break;
				case "Stahl":		mult /= 2;	break;
				case "Elektro":		mult /= 2;	break;	
				default: break;
				}
			}break;
			case"Gift":{
				switch (Verteidigertyp){
				case "Pflanez":		mult *= 2;	break;
				case "Fee":			mult *= 2;	break;
				case "Stahl":		mult *= 2;	break;	
				case "Feuer":		mult *= 2;	break;	

				case "Gestein":		mult /= 2;	break;
				case "Boden":		mult /= 2;	break;
				case "Gift":		mult /= 2;	break;						
				case "Geist":		mult /= 2;	break;	
				default: break;
				}
			}break;
			case"Boden":{
				switch (Verteidigertyp){
				case "Gift":		mult *= 2;	break;
				case "Gestein":		mult *= 2;	break;
				case "Stahl":		mult *= 2;	break;						
				case "Feuer":		mult *= 2;	break;						
				case "Elektro":		mult *= 2;	break;						
				
				case "Käfer":		mult /= 2;	break;
				case "Boden":		mult /= 2;	break;
				case "Pflanze":		mult /= 2;	break;
				default: break;
				}
			}break;
			case"Gestein":{
				switch (Verteidigertyp){
				case "Flug":		mult *= 2;	break;
				case "Käfer":		mult *= 2;	break;
				case "Feuer":		mult *= 2;	break;						
				case "Eis":			mult *= 2;	break;						
				
				case "Kampf":		mult /= 2;	break;
				case "Boden":		mult /= 2;	break;
				case "Stahl":		mult /= 2;	break;
				default: break;
				}
			}break;			
			case"Käfer":{
				switch (Verteidigertyp){
				case "Psycho":		mult *= 2;	break;
				case "Unlicht":		mult *= 2;	break;
				case "Pflane":		mult *= 2;	break;	
				
				case "Flug":		mult /= 2;	break;
				case "Gift":		mult /= 2;	break;
				case "Kampf":		mult /= 2;	break;	
				case "Geist":		mult /= 2;	break;
				case "Stahl":		mult /= 2;	break;						
				case "Feuer":		mult /= 2;	break;						
				case "Fee":			mult /= 2;	break;	
				default: break;
				}
			}break;
			case"Geist":{
				switch (Verteidigertyp){
				case "Geist":		mult *= 2;	break;
				case "Psycho":		mult *= 2;	break;
				
				case "Unlicht":		mult /= 2;	break;	
				default: break;
				}
			}break;
			case"Stahl":{
				switch (Verteidigertyp){
				case "Fee":			mult *= 2;	break;
				case "Gestein":		mult *= 2;	break;
				case "Eis":			mult *= 2;	break;
				
				case "Stahl":		mult /= 2;	break;
				case "Feuer":		mult /= 2;	break;
				case "Wasser":		mult /= 2;	break;	
				case "Elektro":		mult /= 2;	break;					
				default: break;
				}
			}break;
			case"Feuer":{
				switch (Verteidigertyp){
				case "Pflanze":		mult *= 2;	break;
				case "Käfer":		mult *= 2;	break;
				case "Stahl":		mult *= 2;	break;	
				case "Eis":			mult *= 2;	break;
			
				case "Gestein":		mult /= 2;	break;
				case "Feuer":		mult /= 2;	break;
				case "Wasser":		mult /= 2;	break;	
				case "Drache":		mult /= 2;	break;					
				default: break;
				}
			}break;
			case"Wasser":{
				switch (Verteidigertyp){
				case "Feuer":		mult *= 2;	break;
				case "Gestein":		mult *= 2;	break;
				case "Boden":		mult *= 2;	break;	
				
				case "Pflanze":		mult /= 2;	break;
				case "Wasser":		mult /= 2;	break;	
				case "Drache":		mult /= 2;	break;						
				default: break;
				}
			}break;
			case"Pflanze":{
				switch (Verteidigertyp){
				case "Wasser":		mult *= 2;	break;
				case "Gestein":		mult *= 2;	break;
				case "Boden":		mult *= 2;	break;
				
				case "Flug":		mult /= 2;	break;
				case "Gift":		mult /= 2;	break;
				case "Käfer":		mult /= 2;	break;	
				case "Pflanze":		mult /= 2;	break;
				case "Drache":		mult /= 2;	break;	
				case "Stahl":		mult /= 2;	break;
				case "Feuer":		mult /= 2;	break;
				default: break;
				}
			}break;
			case"Elektro":{
				switch (Verteidigertyp){
				case "Wasser":		mult *= 2;	break;
				case "Flug":		mult *= 2;	break;

				case "Elektro":		mult /= 2;	break;	
				case "Pflanze":		mult /= 2;	break;
				case "Drache":		mult /= 2;	break;	
				default: break;
				}
			}break;
			case"Psycho":{
				switch (Verteidigertyp){
				case "Kampf":		mult *= 2;	break;
				case "Gift":		mult *= 2;	break;
				
				case "Stahl":		mult /= 2;	break;
				case "Psycho":		mult /= 2;	break;
				default: break;
				}
			}break;
			case"Eis":{
				switch (Verteidigertyp){
				case "Pflanze":		mult *= 2;	break;
				case "Flug":		mult *= 2;	break;
				case "Boden":		mult *= 2;	break;
				case "Drache":		mult *= 2;	break;

				case "Wasser":		mult /= 2;	break;
				case "Eis":			mult /= 2;	break;	
				case "Stahl":		mult /= 2;	break;
				case "Feuer":		mult /= 2;	break;
				default: break;
				}
			}break;
			case"Drache":{
				switch (Verteidigertyp){
				case "Drache":		mult *= 2;	break;
	
				case "Stahl":		mult /= 2;	break;
				default: break;
				}
			}break;
			case"Unlicht":{
				switch (Verteidigertyp){
				case "Psycho":		mult *= 2;	break;
				case "Geist":		mult *= 2;	break;
				
				case "Kampf":		mult /= 2;	break;	
				case "Fee":			mult /= 2;	break;
				case "Unlicht":		mult /= 2;	break;
				default: break;
				}
			}break;
			case"Fee":{
				switch (Verteidigertyp){
				case "Drache":		mult *= 2;	break;
				case "Unlicht":		mult *= 2;	break;
				case "Kampf":		mult *= 2;	break;

				case "Gift":		mult /= 2;	break;	
				case "Stahl":		mult /= 2;	break;
				case "Feuer":		mult /= 2;	break;
				default: break;
				}
			}break;
			default: break;
			
			}				
			return mult;
		}
	

}
