package PkmnObjekt;
//import BattletoolsDM.Daten_Kampfteilnehmer;
//import StatCalc.CreatePkmnObject;

//MCV Modell-View
public class showPokemonObjekt {

	public static void main(String[] args) {
		CreatePkmnObject.Datenbelegung();
		
		CreatePkmnObject.cp1.writeComplexReport();
		CreatePkmnObject.cp2.writeComplexReport();
		CreatePkmnObject.cp3.writeComplexReport();		
		
		System.out.println("Die höchsten HP hat:" + checkHighestHP(CreatePkmnObject.cp1, CreatePkmnObject.cp2, CreatePkmnObject.cp3));
		System.out.println("Die höchsten Atk hat:" + checkHighestAtk(CreatePkmnObject.cp1, CreatePkmnObject.cp2, CreatePkmnObject.cp3));
		System.out.println("Die höchsten Def hat:" + checkHighestDef(CreatePkmnObject.cp1, CreatePkmnObject.cp2, CreatePkmnObject.cp3));
		System.out.println("Die höchsten SAtk hat:" + checkHighestSAtk(CreatePkmnObject.cp1, CreatePkmnObject.cp2, CreatePkmnObject.cp3));
		System.out.println("Die höchsten SDef hat:" + checkHighestSDef(CreatePkmnObject.cp1, CreatePkmnObject.cp2, CreatePkmnObject.cp3));
		System.out.println("Die höchsten Init hat:" + checkHighestInit(CreatePkmnObject.cp1, CreatePkmnObject.cp2, CreatePkmnObject.cp3));
	}
	
	public static String checkHighestHP(CustomComplexPkmn sample1 ,CustomComplexPkmn sample2, CustomComplexPkmn sample3) {
		String winner= "Hier stimmt was nicht";
		if ((sample1.getHP()>sample2.getHP())&&(sample1.getHP()>sample3.getHP())) {
			winner = sample1.getName();
		}else if((sample1.getHP()<sample2.getHP())&&(sample2.getHP()>sample3.getHP())) {
			winner = sample2.getName();
		}else if ((sample1.getHP()<sample3.getHP())&&(sample2.getHP()<sample3.getHP())){
			winner = sample3.getName();
		}
		return winner;
	}
	public static String checkHighestAtk(CustomComplexPkmn sample1 ,CustomComplexPkmn sample2, CustomComplexPkmn sample3) {
		String winner= "Hier stimmt was nicht";
		if ((sample1.getAtk()>sample2.getAtk())&&(sample1.getAtk()>sample3.getAtk())) {
			winner = sample1.getName();
		}else if((sample1.getAtk()<sample2.getAtk())&&(sample2.getAtk()>sample3.getAtk())) {
			winner = sample2.getName();
		}else if ((sample1.getAtk()<sample3.getAtk())&&(sample2.getAtk()<sample3.getAtk())){
			winner = sample3.getName();
		}
		return winner;
	}
	public static String checkHighestDef(CustomComplexPkmn sample1 ,CustomComplexPkmn sample2, CustomComplexPkmn sample3) {
		String winner= "Hier stimmt was nicht";
		if ((sample1.getDef()>sample2.getDef())&&(sample1.getDef()>sample3.getDef())) {
			winner = sample1.getName();
		}else if((sample1.getDef()<sample2.getDef())&&(sample2.getDef()>sample3.getDef())) {
			winner = sample2.getName();
		}else if ((sample1.getDef()<sample3.getDef())&&(sample2.getDef()<sample3.getDef())){
			winner = sample3.getName();
		}
		return winner;
	}
	public static String checkHighestSAtk(CustomComplexPkmn sample1 ,CustomComplexPkmn sample2, CustomComplexPkmn sample3) {
		String winner= "Hier stimmt was nicht";
		if ((sample1.getSAtk()>sample2.getSAtk())&&(sample1.getSAtk()>sample3.getSAtk())) {
			winner = sample1.getName();
		}else if((sample1.getSAtk()<sample2.getSAtk())&&(sample2.getSAtk()>sample3.getSAtk())) {
			winner = sample2.getName();
		}else if ((sample1.getSAtk()<sample3.getSAtk())&&(sample2.getSAtk()<sample3.getSAtk())){
			winner = sample3.getName();
		}
		return winner;
	}
	public static String checkHighestSDef(CustomComplexPkmn sample1 ,CustomComplexPkmn sample2, CustomComplexPkmn sample3) {
		String winner= "Hier stimmt was nicht";
		if ((sample1.getSDef()>sample2.getSDef())&&(sample1.getSDef()>sample3.getSDef())) {
			winner = sample1.getName();
		}else if((sample1.getSDef()<sample2.getSDef())&&(sample2.getSDef()>sample3.getSDef())) {
			winner = sample2.getName();
		}else if ((sample1.getSDef()<sample3.getSDef())&&(sample2.getSDef()<sample3.getSDef())){
			winner = sample3.getName();
		}
		return winner;
	}
	public static String checkHighestInit(CustomComplexPkmn sample1 ,CustomComplexPkmn sample2, CustomComplexPkmn sample3) {
		String winner= "Hier stimmt was nicht";
		if ((sample1.getInit()>sample2.getInit())&&(sample1.getInit()>sample3.getInit())) {
			winner = sample1.getName();
		}else if((sample1.getInit()<sample2.getInit())&&(sample2.getInit()>sample3.getInit())) {
			winner = sample2.getName();
		}else if ((sample1.getInit()<sample3.getInit())&&(sample2.getInit()<sample3.getInit())){
			winner = sample3.getName();
		}
		return winner;
	}

}
