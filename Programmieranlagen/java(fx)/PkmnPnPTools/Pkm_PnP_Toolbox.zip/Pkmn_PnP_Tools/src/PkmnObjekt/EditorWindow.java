package PkmnObjekt;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import BattletoolsDM.Daten_Kampfteilnehmer;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.*;

public class EditorWindow {

	public static boolean EditPkmn() {
		
		Stage windowEdit = new Stage ();
		
		
		//Diese Klasse sperrt das Parent-window
		windowEdit.initModality(Modality.APPLICATION_MODAL);	
		windowEdit.setTitle("Edit: "+AttackCalcGUI.editoring.getName());
		windowEdit.setMinWidth(450);
		windowEdit.setMinHeight(400);
		
		GridPane grid3x12 = new GridPane();
		grid3x12.setPadding(new Insets(0,0,0,0));
		grid3x12.setVgap(15);
		grid3x12.setHgap(15);
		
		
		Label headline = new Label("Editing: "+AttackCalcGUI.editoring.getName());
		GridPane.setConstraints(headline, 1, 2);
		
		final Label Nametxt = new Label ("Name:");
		final Label Typestxt = new Label ("Typen:");
		final Label HPtxt = new Label ("Kraftpunkte:");
		final Label Atktxt = new Label ("Angriff:");
		final Label Deftxt = new Label ("Verteidigung:");
		final Label SAtktxt = new Label ("Sp.Ang:");
		final Label SDeftxt = new Label ("Sp.Ver:");
		final Label Inittxt = new Label ("Initiative:");
		setIntoGridHorizontal(Nametxt, Typestxt, HPtxt, Atktxt, Deftxt, SAtktxt, SDeftxt, Inittxt, 1, 4, 1);
		
		TextField Name = new TextField();
		Name.setText(AttackCalcGUI.editoring.getName());
		ChoiceBox<String> Type1 = new ChoiceBox<String>();
		Type1.getItems().addAll("Normal","Feuer","Wasser","Pflanze","Flug","Kampf","Gift","Elektro","Boden","Gestein","Psycho","Eis","Käfer","Geist","Stahl","Drache","Unlicht","Fee","Typenlos");
		Type1.setValue(AttackCalcGUI.editoring.getType1());
		TextField HP = new TextField();
		HP.setText(""+AttackCalcGUI.editoring.getHP());
		TextField Atk = new TextField();
		Atk.setText(""+AttackCalcGUI.editoring.getAtk());
		TextField Def = new TextField();
		Def.setText(""+AttackCalcGUI.editoring.getDef());
		TextField SAtk = new TextField();
		SAtk.setText(""+AttackCalcGUI.editoring.getSAtk());
		TextField SDef = new TextField();
		SDef.setText(""+AttackCalcGUI.editoring.getSDef());
		TextField Init = new TextField();
		Init.setText(""+AttackCalcGUI.editoring.getInit());
		setIntoGridHorizontal(Name, Type1, HP, Atk, Def, SAtk, SDef, Init, 2, 4, 1);		
		setMultipleWith(80, Name, HP, Atk, SAtk, SDef, Def, SDef, Init);

		ChoiceBox<String> Type2 = new ChoiceBox<String>();
		Type2.getItems().addAll("Normal","Feuer","Wasser","Pflanze","Flug","Kampf","Gift","Elektro","Boden","Gestein","Psycho","Eis","Käfer","Geist","Stahl","Drache","Unlicht","Fee","Typenlos");
		Type2.setValue(AttackCalcGUI.editoring.getType2());
		GridPane.setConstraints(Type2, 3, 5);
		
		Button apply = new Button("Apply");
		GridPane.setConstraints(apply, 3, 13);
		
		apply.setOnAction(e->{
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setName(Name.getText());
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setType1(Type1.getValue());
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setType2(Type2.getValue());
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setHP(intfromTextField(HP));
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setAtk(intfromTextField(Atk));
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setDef(intfromTextField(Def));
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setSAtk(intfromTextField(SAtk));
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setSDef(intfromTextField(SDef));
			CreatePkmnObjectForBattletools.Teilnehmerliste[AttackCalcGUI.changeID].setInit(intfromTextField(Init));
			
			AttackCalcGUI.EditTeilnehmer[AttackCalcGUI.changeID].setText(Name.getText());
		});
		
		
		grid3x12.getChildren().addAll(headline,Nametxt,Typestxt,HPtxt,Atktxt,Deftxt,SAtktxt,SDeftxt,Inittxt,
				Name,Type1,Type2,HP,Atk,SAtk,Def,SDef,Init,apply);
		
		Scene editing = new Scene(grid3x12);
		windowEdit.setScene(editing);
		windowEdit.showAndWait();
		
		return true;
	}
	public static void setIntoGridHorizontal (Label l1, Label l2, Label l3, Label l4, Label l5, Label l6, Label l7, Label l8, 
			int XAxis,int start, int every) {
		Label [] list = {l1,l2,l3,l4,l5,l6,l7,l8};
		int position = start;
		
		for (int i = 0; i<list.length; i++ ) {
		GridPane.setConstraints(list[i], XAxis, position);
		position += every;
		}
	}
	public static void setIntoGridHorizontal (TextField t1, ChoiceBox<String> C1 ,TextField t2, TextField t3, TextField t4, TextField t5, TextField t6, TextField t7,  
			int XAxis,int start, int every) {
		TextField [] list = {t2 ,t3 ,t4 ,t5 ,t6 ,t7};
		int position = start;
		
		GridPane.setConstraints(t1, XAxis, position);
		position += every;
		GridPane.setConstraints(C1, XAxis, position);
		position += every;
		
		for (int i = 0; i<list.length; i++ ) {
			GridPane.setConstraints(list[i], XAxis, position);
			position += every;
		}
	}
	public static void setMultipleWith(int width, TextField a,TextField b,TextField c,TextField d,TextField e,TextField f,TextField g,TextField h) {
	TextField [] list = { a, b, c, d, e, f, g, h};
	for (int i =0; i< list.length ;i++) {
		list[i].setMaxWidth(width);
	}	
	}
	public static int intfromTextField(TextField input) {
		int sample;
		try { 
			sample = Integer.parseInt(input.getText());
		} catch (NumberFormatException e) {
			sample = 0;
		}
		return sample;
	}
}
