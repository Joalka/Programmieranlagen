package PkmnObjekt;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import BattletoolsDM.Daten_Kampfteilnehmer;
import javafx.geometry.*;

public class PickDefendentWindow {
	
		static CustomPkmn[] Verteidiger = new CustomPkmn[CreatePkmnObjectForBattletools.Teilnehmerliste.length];
		static boolean resultrdy = false;

	
		public static boolean wähleVerteidiger() {
			

	 
	 
			Stage windowVerteidiger = new Stage ();
			
			//Diese Klasse sperrt das Parent-window
			windowVerteidiger.initModality(Modality.APPLICATION_MODAL);	
			windowVerteidiger.setTitle("wähle Verteidiger");
			windowVerteidiger.setMinWidth(150);
			windowVerteidiger.setMinHeight(300);
			
			GridPane grid2x10 = new GridPane();
			grid2x10.setPadding(new Insets(0,0,0,0));
			grid2x10.setVgap(15);
			grid2x10.setHgap(15);
			
			CheckBox CBlist [] = new CheckBox[CreatePkmnObjectForBattletools.Teilnehmerliste.length];
			
			for (int i = 0; i<CBlist.length;i++) {
				CBlist[i]= new CheckBox(""+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getName());
				if (i<5) {
					GridPane.setConstraints(CBlist[i], 0, i);
				}else if (i<10) {
					GridPane.setConstraints(CBlist[i], 1, i-5);
				}else if (i<15) {
					GridPane.setConstraints(CBlist[i], 2, i-10);
				}
				grid2x10.getChildren().add(CBlist[i]);
			}
			

			
			
			Button ConfirmButton = new Button("Confirm");
			ConfirmButton.setOnAction(e->{
				Verteidiger = new CustomPkmn[CreatePkmnObjectForBattletools.Teilnehmerliste.length];
				int a = 0;
				for (int i=0; i<CBlist.length;i++) {
					if (CBlist[i].isSelected()) {
						Verteidiger[a] = CreatePkmnObjectForBattletools.Teilnehmerliste[i];
						System.out.println("Liste Verteidiger bekommt neuen Eintrag: Listenplatz "+a+Verteidiger[a].getName());
						Verteidiger[a] = CreatePkmnObjectForBattletools.Teilnehmerliste[i];
						a++;
					}
				}
				Verteidiger=killnull(Verteidiger);
				if (Verteidiger.length>0) {
					resultrdy = true;
				}
				windowVerteidiger.close();
			});
			
			GridPane.setConstraints(ConfirmButton, 1, 6);
			
			grid2x10.getChildren().add(ConfirmButton);
			
			Scene pickDefendent = new Scene(grid2x10);
			windowVerteidiger.setScene(pickDefendent);
			windowVerteidiger.showAndWait();
		
			return true;
			
		
		}
		public static CustomPkmn[] killnull(CustomPkmn[] check) {
			int l = 0;
			for (int i=0; i<check.length;i++) {
				if(check[i]!= null) {
					l++;
				}
			}
			CustomPkmn[]fresh =new CustomPkmn[l];
			for (int i=0; i<check.length;i++) {
				if(check[i]!= null) {
					fresh[i]=check[i];
				}
			}
			return fresh;
		}
	

}
