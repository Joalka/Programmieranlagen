package PkmnObjekt;

//MVC-Pattern Modell1
public class CustomPkmn {

	private String name = "Placeholdmon";
	
	private String Type1 = "Typeless";
	private String Type2 = "";
		
	private int HP = 30;
	private int Atk = 30;
	private int Def = 30;
	private int SAtk = 30;
	private int SDef = 30;
	private int Init = 0;
	
	
	
	//Konstruktor
	public CustomPkmn(String name, String Type1 ,String Type2 ,int HP, int Atk, int Def, int SAtk, int SDef, int Init) {
		this.name = name;
		
		this.Type1 = Type1;
		this.Type2 = Type2;
		
		this.HP = HP;
		this.Atk = Atk;
		this.Def = Def;
		this.SAtk = SAtk;
		this.SDef = SDef;
		this.Init = Init;
	}

	
	public CustomPkmn(String name, String Type1 ,String Type2 ,int [] arr) {
		this.name = name;
		
		this.Type1 = Type1;
		this.Type2 = Type2;
		
		HP = arr[0];
		Atk = arr[1];
		Def =arr[2];
		SAtk = arr[3];
		SDef = arr[4];
		Init = arr[5];
	}
	
	//Setter Methoden
	public void setName(String name) {
		this.name=name;
	}
	public void setType1(String Type) {
		Type1=Type;
		}
	public void setType2(String Type) {
		Type2=Type;
	}
	
	public void setHP(int HP) {
		this.HP=HP;
	}
	
	public void setAtk(int Atk) {
		this.Atk=Atk;
	}
	
	public void setDef(int Def) {
		this.Def=Def;
	}
	
	public void setSAtk(int SAtk) {
		this.SAtk=SAtk;
	}
	
	public void setSDef(int SDef) {
		this.SDef=SDef;
	}
	
	public void setInit(int Init) {
		this.Init=Init;
	}
	
	public void setStatBlock(int[] arr){
		if(arr.length == 6){
		HP = arr[0];
		Atk = arr[1];
		Def = arr[2];
		SAtk = arr[3];
		SDef = arr[4];
		Init = arr[5];
		}
	}
	
	//Getter Methoden
	public String getName() {
		return name;
	}
	public String getType1() {
		System.out.println("Type1: " + Type1);
		return Type1;
	}
	public String getType2() {
		System.out.println("Type2: " + Type2);
		return Type2;
	}
	
	public int getHP() {
		return HP;
	}
	
	public int getAtk() {
		return Atk;
	}
	
	public int getDef() {
		return Def;
	}
	
	public int getSAtk() {
		return SAtk;
	}
	
	public int getSDef() {
		return SDef;
	}
	
	public int getInit() {
			return Init;
	}
	public int[] getStatBlock() {
		int[] arr = {HP, Atk, Def, SAtk, SDef, Init};
		return arr;
	}
	//write Methoden
	
	public String writename() {
		System.out.println("Name: "+name);
		return name;
	}
	public void writeTypes() {
		System.out.println("Types: " + Type1+"\t"+Type2);	
	}
	
	public int writeHP() {
		System.out.println("HP: "+HP);
		return HP;
	}
	
	public int writeAtk() {
		System.out.println("Atk: "+Atk);
		return Atk;
	}
	
	public int writeDef() {
		System.out.println("Def: "+Def);
		return Def;
	}
	
	public int writeSAtk() {
		System.out.println("SAtk: "+SAtk);
		return SAtk;
	}
	
	public int writeSDef() {
		System.out.println("SDef: "+SDef);
		return SDef;
	}
	
	public int writeInit() {
		System.out.println("Init: "+Init);
			return Init;
	}
	
	public void writeStats() {
		writeHP();
		writeAtk();
		writeDef();
		writeSAtk();
		writeSDef();
		writeInit();
	}
	public void writeReport() {
		System.out.println("\nReport:\n------------------------------");
		writename();
		writeTypes();
		System.out.println();
		writeStats();
		System.out.println("------------------------------");
	}
	
}
