package PkmnObjekt;

//MVC-Pattern Modell2
public class CustomComplexPkmn extends CustomPkmn{
	
	public static CustomComplexPkmn [] sammlung;
	
	private int lvl = 1;
	

	
	private String [] ability = {"","","","","",""};
	
	private String [] talent = {"","","","","","","","","","","",""};
	
	
	
	
	//Konstruktor
	public CustomComplexPkmn(String name, int lvl, int HP, int Atk, int Def, int SAtk, int SDef, int Init, String Type1, String Type2, String ability) {
		super (name,Type1,Type2,HP,Atk,Def,SAtk,SDef,Init);
		
		this.lvl = lvl;

		this.ability [0] = ability;	
		

	}
	public CustomComplexPkmn(String name, int lvl, int []arr, String Type1, String Type2, String ability) {
		super (name, Type1, Type2, arr);
		
		this.lvl = lvl;

		this.ability [0] = ability;	
	}
	
	//Setter Methoden	
	public void setlvl(int lvl) {
		this.lvl=lvl;
	}

	public void setAbility(int id,String ability) {
		System.out.print("Ability "+ id + ": "+this.ability[id]+" wurde geändert zu ");
		this.ability[id]=ability;
		System.out.println(this.ability[id]);
	}
	public void setTalent(int id,String talent) {
		System.out.print("talent:\n"+this.talent[id]+"\nwurde geändert zu\n");
		this.talent[id]=talent;
		System.out.println(this.talent[id]);
	}
	
	//Getter Methoden
	public int getlvl() {
		return lvl;
	}

	public String getAbility(int id) {
		System.out.println("Ability "+id+": " +ability[id] );
		return ability[id];
	}
	public String getTalent(int id) {
		System.out.println("talent "+id+": " +talent[id] );
		return talent[id];
	}
	
	//write Methoden
	public int writelvl() {
		System.out.println("Level: " + lvl);
		return lvl;
	}

	public void writeAbilities() {
		for (int id=0; id<ability.length;id++) {
			if (!(ability[id].equals("")))
			System.out.println("Ability "+id+": " +ability[id] );
		}
	}
	public void writeTalents() {
		for (int id=0; id<talent.length;id++) {
			if (!(talent[id].equals("")))
			System.out.println("Talent "+id+": " +talent[id] );
		}
	}
	
	public void writeComplexReport() {
		System.out.println("\nReport:\n------------------------------");
		writename();
		writelvl();
		writeStats();
		System.out.println();
		writeTypes();
		System.out.println();
		writeAbilities();
		System.out.println();
		writeTalents();
		System.out.println("------------------------------");
	}
	
}
