package PkmnObjekt;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;

public class ConfirmBox {

	static boolean answer;
	
	public static boolean display(String title, String message) {
		Stage window = new Stage ();
		
		//Diese Klasse sperrt das Parent-window
		window.initModality(Modality.APPLICATION_MODAL);	
		window.setTitle("Sicher?");
		window.setMinWidth(250);
		
		Label main_question = new Label();
		main_question.setText("Möchtest du wirklich das Fenster schließen?\nWenn du das Programm schließt,\nwerden veränderte Daten auf ihren Originalstand zurückgesetzt!");
		
		Button YesButton = new Button("JA!");
		YesButton.setOnAction(e->{
			answer = true;
			window.close();
		});
		
		Button NoButton = new Button("Nein");
		NoButton.setOnAction(e->{
			answer = false;
			window.close();
		});
		
		VBox body = new VBox(15);
		body.getChildren().addAll(main_question,YesButton, NoButton);
		body.setAlignment(Pos.CENTER);
		
		Scene main_scene = new Scene(body);
		window.setScene(main_scene);
		window.showAndWait();
		
		return answer;
			
			
			
		}
	

}
