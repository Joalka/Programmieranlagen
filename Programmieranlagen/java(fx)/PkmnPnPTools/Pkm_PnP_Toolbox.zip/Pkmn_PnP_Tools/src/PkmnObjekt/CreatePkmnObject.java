package PkmnObjekt;
import StatCalc.Pkmn_Liste_Import;

//MVC-Pattern Controller
public class CreatePkmnObject {
	
	
	public static CustomComplexPkmn cp1;
	public static CustomComplexPkmn cp2;
	public static CustomComplexPkmn cp3;
	
	
	
	public static void Datenbelegung() {
		
	
		cp1 = new CustomComplexPkmn("Karnimani X",12,50,65,64,44,48,43, "Wasser","Gestein","Sturzbach");//("Karnimani X",12,50,65,64,44,48,43, "Wasser","Gestein","Sturzbach");
//		cp1.setName("Karnimani X");
//		cp1.setlvl(12);
//		cp1.setStatBlock(Pkmn_Liste_Import.liste[1029]);	//{/*Karnimani X*/50,65,64,44,48,43}
//		cp1.setType1("Wasser");
//		cp1.setType2("Gestein");
//		cp1.setAbility(0, "Sturzbach");
		cp1.setAbility(1, "Titankiefer");
		cp1.setTalent(0, "Beeinträchtigung wuchernde Steinzähne: Das Pokemon verletzt sich selbst regelmäßig mit den spitzen und krum gewachsenen Zähnen, da sie nicht zum Mundesinneren passen");
		cp1.setTalent(1, "Beeinträchtigung ADHS: Das Pokemon istschnell von neuem motiviert/interessiert und hat sehr viel Energie, welche es rauslassen muss");
	
		cp2 = new CustomComplexPkmn(Pkmn_Liste_Import.name[1032],10,Pkmn_Liste_Import.stats[1032],"Feuer","","Großbrand");
//		cp2.setType2("Psycho");
		cp2.setAbility(1, "Erfassen");
		cp2.setTalent(0, "übernatürliches Gehöhr: Das Pokemon kann über die metallenen Piercing in den Ohren Schall sowie Psywellen besser empfangen. Das ermöglicht je nach Level Gedanken lesen und extreme Geräuschwahrnehmung und das Filtern dieser.");
		cp2.setTalent(1, "Beeinträchtigung überlastete Wahrnehmung (ünernatürliches Gehöhr): Das Pokemon bekommt sehr schnell Kopfschmerzen wenn es sich nicht der Wahrnehmung entziehen kann. Sound Angriffe verursachen 2 fachen Schaden");
		
		cp3 = new CustomComplexPkmn("Endivie X",10,45,37,81,37,81,45,"Pflanze","","Notdünger");
//		cp3.setStatBlock(Pkmn_Liste_Import.liste[1026]);	//{/*Endivie X*/45,37,81,37,81,45}
		cp3.setAbility(1, "Speckschicht");
		cp3.setTalent(0, "Beeinträchtigung chronische Übelkeit: Der Körper fühlt sich leicht aufgeblasen an und das Pokemon hat regelmäßige Übelkeit und Verdauungsprobleme. Vor allem wenn der Körper geschüttelt wird (Wasserballon)");
		
	}
	

	
		


}
