package PkmnObjekt;
import StatCalc.Pkmn_Liste_Import;
import BattletoolsDM.*;

//MVC-Pattern Controller
public class CreatePkmnObjectForBattletools {
	
	//für Export in "Angriffsschaden berechnen"
	public static CustomPkmn t0;
	public static CustomPkmn t1;
	public static CustomPkmn t2;
	public static CustomPkmn t3;
	public static CustomPkmn t4;
	public static CustomPkmn t5;
	public static CustomPkmn t6;
	public static CustomPkmn t7;
	public static CustomPkmn t8;
	public static CustomPkmn t9;
	public static CustomPkmn t10;
	public static CustomPkmn t11;
	public static CustomPkmn t12;
	public static CustomPkmn t13;
	public static CustomPkmn t14;
	public static CustomPkmn [] Teilnehmerliste= {t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14};
	
	public static void Datenbelegung() {
		
		Teilnehmerliste[0] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[0], "Normal", "", Daten_Kampfteilnehmer.Stats[0]);		
		Teilnehmerliste[1] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[1], "Normal", "", Daten_Kampfteilnehmer.Stats[1]);
		Teilnehmerliste[2] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[2], "Eis", "", Daten_Kampfteilnehmer.Stats[2]);
		Teilnehmerliste[3] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[3], "Boden", "Geist", Daten_Kampfteilnehmer.Stats[3]);
		Teilnehmerliste[4] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[4], "Käfer", "Kampf", Daten_Kampfteilnehmer.Stats[4]);
		Teilnehmerliste[5] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[5], "Flug", "Elektro", Daten_Kampfteilnehmer.Stats[5]);
		Teilnehmerliste[6] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[6], "Feuer", "Flug", Daten_Kampfteilnehmer.Stats[6]);
		Teilnehmerliste[7] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[7], "Wasser", "Käfer", Daten_Kampfteilnehmer.Stats[7]);
		Teilnehmerliste[8] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[8], "Fee", "Psycho", Daten_Kampfteilnehmer.Stats[8]);
		Teilnehmerliste[9] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[9], "Flug", "Eis", Daten_Kampfteilnehmer.Stats[9]);
		Teilnehmerliste[10] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[10], "", "", Daten_Kampfteilnehmer.Stats[10]);
		Teilnehmerliste[11] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[11], "", "", Daten_Kampfteilnehmer.Stats[11]);
		Teilnehmerliste[12] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[12], "", "", Daten_Kampfteilnehmer.Stats[12]);
		Teilnehmerliste[13] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[13], "", "", Daten_Kampfteilnehmer.Stats[13]);
		Teilnehmerliste[14] = new CustomPkmn(Daten_Kampfteilnehmer.Teilnehmer[14], "", "", Daten_Kampfteilnehmer.Stats[14]);
		
	

	}
	

	
		


}
