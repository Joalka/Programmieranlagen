package PkmnObjekt;


import BattletoolsDM.AngriffeHpBerechnen;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.beans.binding.NumberBinding;



public class AttackCalcGUI extends Application{
	
	Stage window;
	Scene scene, refresh;
	
	static TextField nbPower;
	static TextField nbAtkMult;
	static CheckBox SAtk;
	static ChoiceBox<String> AtkType;
	
	static CustomPkmn editoring;
	static int changeID;
	static Button EditTeilnehmer[] = new Button[CreatePkmnObjectForBattletools.Teilnehmerliste.length];

	public static void main(String[] args) {
		
		CreatePkmnObjectForBattletools.Datenbelegung();
		launch(args);
	}
	@Override
	public void start(Stage primaryStage) throws Exception{
		
		window= primaryStage;
		window.setTitle("Angriffsschaden berechnen");

		window.setOnCloseRequest(e->{
			e.consume();
			closeProgram();
		});
		
		GridPane maingrid = new GridPane();
		maingrid.setPadding(new Insets(0,0,0,0));
		maingrid.setVgap(15);
		maingrid.setHgap(15);
		


		//Aufbau der Grid-elemente
		final Label Angreifertxt = new Label ("Angreifer:");
		final Label Powertxt = new Label ("Power:");
		final Label AtkMulttxt = new Label ("Atk mult:");
		final Label AtkTypetxt = new Label ("Atk Type:");
		final Label Verteidigertxt = new Label ("Verteidiger");
		final Label Resultstxt = new Label ("Ergebnis:");
		GridPane.setConstraints(Angreifertxt, 2, 1);
		setIntoGridVertikal(Powertxt, AtkMulttxt, AtkTypetxt, Verteidigertxt, Resultstxt, 4, 1, 1);
		final Label Edittxt = new Label ("Edit:");
		GridPane.setConstraints(Edittxt, 1, 6);
		
		
		
		


		for (int i = 0; i<EditTeilnehmer.length;i++) {
			EditTeilnehmer[i]= new Button(""+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getName());
			maingrid.getChildren().add(EditTeilnehmer[i]);
			if (i<10) {
			GridPane.setConstraints(EditTeilnehmer[i], i+1, 7);
			} else if (i<20) {
				GridPane.setConstraints(EditTeilnehmer[i], i-9, 8);	
			}
		}
		
		Button pickAngreifer = new Button ("Pick");
		GridPane.setConstraints(pickAngreifer, 2, 2);
		CheckBox Atk = new CheckBox("Physisch");
		GridPane.setConstraints(Atk, 3, 1);
		Atk.setSelected(true);
		SAtk = new CheckBox("Speziel");
		GridPane.setConstraints(SAtk, 3, 2);
		nbPower = new TextField();
		nbPower.setPromptText("60");
		nbPower.setText("40");
		GridPane.setConstraints(nbPower, 4, 2);
		nbAtkMult = new TextField();
		nbAtkMult.setPromptText("0.8");
		nbAtkMult.setText("1.0");		
		GridPane.setConstraints(nbAtkMult, 5, 2);
		AtkType = new ChoiceBox<>();
		AtkType.getItems().addAll("Normal","Feuer","Wasser","Pflanze","Flug","Kampf","Gift","Elektro","Boden","Gestein","Psycho","Eis","Käfer","Geist","Stahl","Drache","Unlicht","Fee","Typenlos");
		AtkType.setValue("Typenlos");
		GridPane.setConstraints(AtkType, 6, 2);
		Button pickVerteidiger = new Button ("Pick");
		GridPane.setConstraints(pickVerteidiger, 7, 2);
		Button showResults = new Button ("Show");
		GridPane.setConstraints(showResults, 8, 2);
		
		nbPower.setMaxWidth(40);
		nbAtkMult.setMaxWidth(40);
		
		Button data = new Button ("get Data");
		GridPane.setConstraints(data, 2, 6);
		
		
		
		//Button Funktionen
		pickAngreifer.setOnAction(e ->{
			boolean answer = PickAttackerWindow.wähleAngreifer();
			if (answer) {
				pickAngreifer.setText(PickAttackerWindow.Attacker.getName());
			}
			if (pickAngreifer.getText()=="") {
				pickAngreifer.setText("Pick");
			}
		});
		Atk.setOnAction(e ->{
			SAtk.setSelected(false);
		});
		SAtk.setOnAction(e ->{
			Atk.setSelected(false);
		});
		pickVerteidiger.setOnAction(e ->{
			PickDefendentWindow.wähleVerteidiger();
		});
	
		showResults.setOnAction(e ->{
			System.out.println("Angreifer: "+ PickAttackerWindow.Attacker.getName());
			System.out.println("Atk:  "+ PickAttackerWindow.Attacker.getAtk());
			System.out.println("SAtk: "+ PickAttackerWindow.Attacker.getSAtk());
			System.out.println("Attack Type: "+AtkType.getValue());
			
			for (int i = 0; i<PickDefendentWindow.Verteidiger.length;i++) {
				System.out.println("\nVerteidiger "+ i + ":"+PickDefendentWindow.Verteidiger[i].getName());
				System.out.println("Def:  "+ PickDefendentWindow.Verteidiger[i].getDef());
				System.out.println("SDef: "+ PickDefendentWindow.Verteidiger[i].getSDef());
			}
			if (PickDefendentWindow.resultrdy) {
				calcResultsWindow.calcResults();
			}
			else System.out.println("Es sind keine Verteidiger ausgewählt");
			
		});
		data.setOnAction(e ->{
			for (int i =0; i<CreatePkmnObjectForBattletools.Teilnehmerliste.length; i++) {
				CreatePkmnObjectForBattletools.Teilnehmerliste[i].writeReport();
				System.out.println("ImportFormatData:");
				System.out.println("Name: \""+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getName()+"\"");
				System.out.print("Stats: {"+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getHP());
				System.out.print(","+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getAtk());
				System.out.print(","+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getDef());
				System.out.print(","+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getSAtk());
				System.out.print(","+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getSDef());
				System.out.println(","+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getInit()+"}");
			}
			
			
		});
		EditTeilnehmer[0].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[0];
			changeID=0;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[1].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[1];	
			changeID=1;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[2].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[2];		
			changeID=2;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[3].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[3];		
			changeID=3;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[4].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[4];	
			changeID=4;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[5].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[5];	
			changeID=5;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[6].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[6];
			changeID=6;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[7].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[7];	
			changeID=7;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[8].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[8];	
			changeID=8;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[9].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[9];
			changeID=9;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[10].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[10];
			changeID=10;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[11].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[11];
			changeID=11;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[12].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[12];
			changeID=12;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[13].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[13];
			changeID=13;
			EditorWindow.EditPkmn();
		});
		EditTeilnehmer[14].setOnAction(e->{
			editoring = CreatePkmnObjectForBattletools.Teilnehmerliste[14];	
			changeID=14;
			EditorWindow.EditPkmn();
		});	
	
		
		

		
		
		maingrid.getChildren().addAll(
/*final label*/	Angreifertxt,Powertxt,AtkMulttxt,AtkTypetxt,Verteidigertxt,Resultstxt,Edittxt,
/*Name label*/ 	//nameT0,nameT1,nameT2,nameT3,nameT4,nameT5,nameT6,nameT7,nameT8,nameT9,nameT10,nameT11,nameT12,nameT13,
/*Input*/ 		pickAngreifer,Atk,SAtk,nbPower,nbAtkMult,AtkType,pickVerteidiger,showResults
/*Edit-Buttons*///editT0,editT1,editT2,editT3,editT4,editT5,editT6,editT7, editT8, editT9, editT10, editT11, editT12, editT13, editT14
/*Output Data*/	,data
					);
		
		maingrid.setAlignment(Pos.BASELINE_LEFT);
		
		
		
		
		
		Scene scene =new Scene(maingrid, 920, 350);
		
		
		window.setScene(scene);
		window.show();
	}
	private void closeProgram() {
		boolean answer = ConfirmBox.display("Title", "Are you sure about that?");
		if (answer)
			window.close();
	}
	
	public static void setIntoGridVertikal (Label l1, Label l2, Label l3, Label l4, Label l5, Label l6, Label l7, 
			int start, int every, int YAxis) {
		Label [] list = {l1,l2,l3,l4,l5,l6,l7};
		int position = start;
		
		for (int i = 0; i<list.length; i++ ) {
		GridPane.setConstraints(list[i], position, YAxis);
		position += every;
		}
	}
	
	public static void setIntoGridVertikal (Label l1, Label l2, Label l3, Label l4, Label l5,  
			int start, int every, int YAxis) {
		Label [] list = {l1,l2,l3,l4,l5};
		int position = start;
		
		for (int i = 0; i<list.length; i++ ) {
			GridPane.setConstraints(list[i], position, YAxis);
			position += every;
		}
	}
	
	public static void setIntoGridVertikal (Button B1, Button B2, Button B3, Button B4, Button B5, 
			int start, int every, int YAxis) {
		Button [] list = {B1,B2,B3,B4,B5};
		int position = start;
		
		for (int i = 0; i<list.length; i++ ) {
			GridPane.setConstraints(list[i], position, YAxis);
			position += every;
		}
	}
}
