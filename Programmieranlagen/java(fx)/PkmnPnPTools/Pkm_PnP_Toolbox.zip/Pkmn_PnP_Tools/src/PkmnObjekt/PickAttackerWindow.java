package PkmnObjekt;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import BattletoolsDM.Daten_Kampfteilnehmer;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.*;

public class PickAttackerWindow {

	static CustomPkmn Attacker = new CustomPkmn("", "", "", 5,5,5,5,5,0);

	
		public static boolean wähleAngreifer() {

			Stage windowAttacker = new Stage ();
			
			//Diese Klasse sperrt das Parent-window
			windowAttacker.initModality(Modality.APPLICATION_MODAL);	
			windowAttacker.setTitle("wähle Angreifer");
			windowAttacker.setMinWidth(800);
			windowAttacker.setMinHeight(120);
			
			GridPane grid2x10 = new GridPane();
			grid2x10.setPadding(new Insets(0,0,0,0));
			grid2x10.setVgap(15);
			grid2x10.setHgap(15);
			
			Button pickAttackerButtons[] = new Button[CreatePkmnObjectForBattletools.Teilnehmerliste.length];
			
			
			for (int i = 0; i<pickAttackerButtons.length;i++) {
				pickAttackerButtons[i]= new Button(""+CreatePkmnObjectForBattletools.Teilnehmerliste[i].getName());
				if (i<10) {
					GridPane.setConstraints(pickAttackerButtons[i], i, 0);
				}else if (i<20) {
					GridPane.setConstraints(pickAttackerButtons[i], i-10, 1);
				}
				grid2x10.getChildren().add(pickAttackerButtons[i]);
				
				//was willst du mit final i!?	Wie kann ich die Variable Attacker, welche außerhalb der Lambda Funktion existiert, innerhalb ändern?...
//				pickAttackerButtons[i].setOnAction(e->{
//					Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[i];
//					windowAttacker.close();
//				});
				////oder ausführliche Form
//				pickAttackerButtons[i].setOnAction(new EventHandler<ActionEvent>() {				
//					@Override
//					public void handle(ActionEvent event) {
//						Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[i];
//					}			
//				});
			}			
			pickAttackerButtons[0].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[0];
				windowAttacker.close();
			});
			pickAttackerButtons[1].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[1];
				windowAttacker.close();
			});
			pickAttackerButtons[2].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[2];
				windowAttacker.close();
			});
			pickAttackerButtons[3].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[3];
				windowAttacker.close();
			});
			pickAttackerButtons[4].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[4];
				windowAttacker.close();
			});
			pickAttackerButtons[5].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[5];
				windowAttacker.close();
			});
			pickAttackerButtons[6].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[6];
				windowAttacker.close();
			});
			pickAttackerButtons[7].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[7];
				windowAttacker.close();
			});
			pickAttackerButtons[8].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[8];
				windowAttacker.close();
			});
			pickAttackerButtons[9].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[9];
				windowAttacker.close();
			});
			pickAttackerButtons[10].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[10];
				windowAttacker.close();
			});
			pickAttackerButtons[11].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[11];
				windowAttacker.close();
			});
			pickAttackerButtons[12].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[12];
				windowAttacker.close();
			});
			pickAttackerButtons[13].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[13];
				windowAttacker.close();
			});
			pickAttackerButtons[14].setOnAction(e->{
				Attacker = CreatePkmnObjectForBattletools.Teilnehmerliste[14];
				windowAttacker.close();
			});
			

			Scene pickAttacker = new Scene(grid2x10);
			windowAttacker.setScene(pickAttacker);
			windowAttacker.showAndWait();
		
			return true;
			
		
		}
	

}
