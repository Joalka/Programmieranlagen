package StatCalc;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
//import javafx.scene.layout.BorderPane;
//import javafx.scene.layout.StackPane;
//import javafx.event.ActionEvent;
//import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
//import javafx.scene.layout.StackPane;
//import javafx.scene.layout.VBox;
//import javafx.scene.layout.HBox;
//import javafx.stage.*;
//import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
//import javafx.scene.image.Image;
//import javafx.geometry.Rectangle2D;
//import javafx.scene.image.Image;
//import javafx.scene.image.ImageView;


public class Oberfläche_StatsCalc_V0_2 extends Application {
	
	Stage window;
	
	int AS_HP = 0, AS_Atk = 0, AS_Def = 0, AS_SAtk = 0, AS_SDef = 0, AS_Init = 0;
	int VG =0;
	
	int res_HP = 0;
	int res_Atk = 0;
	int res_Def = 0;
	int res_SAtk = 0;
	int res_SDef = 0;
	int res_Init = 0;
	
	int lvl = 0;
	

	
	public static void main(String[] args) {
		
		int Sondergrupp_start = 1025;

		System.out.println("Gen1:");
		for (int i = 0; i < Pkmn_Liste_Import.name.length; i++) {
			if (i == 151) {
				System.out.println("\nGen2:");
			}
			if (i == 251) {
				System.out.println("\nGen3:");
			}
			if (i == 386) {
				System.out.println("\nGen4:");
			}
			if (i == 493) {
				System.out.println("\nGen5:");
			}
			if (i == 649) {
				System.out.println("\nGen6:");
			}
			if (i == 721) {
				System.out.println("\nGen7:");
			}
			if (i == 809) {
				System.out.println("\nGen8:");
			}
			if (i == 905) {
				System.out.println("\nGen9:");
			}
			if (i == Sondergrupp_start) {
				System.out.println("\nSondergruppe:");
			}
			if (i < Sondergrupp_start) {
				System.out.print("Pkmn DexNr." + (i + 1));
			} else {
				System.out.print("Pkmn Sonderform");
			}
			if (i < 999) {
				System.out.print(":\t" + Pkmn_Liste_Import.name[i]);
			}

			else
				System.out.print(":" + Pkmn_Liste_Import.name[i]);
			if (i < Sondergrupp_start) {
				System.out.print(":  \t");
			} else {
				System.out.print(":  ");
			}
			if (i == 35 || i == 48 || i == 62 || i == 83 || i == 94 || i == 101 || i == 150 || i == 172 || i == 176
					|| i == 177 || i == 359 || i == 652 || i == 721 || i == 770 || i == 844 || i == 920 || i == 1003) {
				System.out.print("\t");
			}
			System.out.println("HP " + Pkmn_Liste_Import.stats[i][0] + "\tAtk " + Pkmn_Liste_Import.stats[i][1]
					+ "\tDef " + Pkmn_Liste_Import.stats[i][2] + "\t Sp.Atk " + Pkmn_Liste_Import.stats[i][3]
					+ "\tSp.Def " + Pkmn_Liste_Import.stats[i][4] + "\tInit " + Pkmn_Liste_Import.stats[i][5]);

		}
		launch(args);
	}
		
		
		
	@Override
	public void start(Stage primaryStage) throws Exception {
		window= primaryStage;
		window.setTitle("Pkmn Stats Calculator");
		
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(4, 4, 4, 4));
		grid.setVgap(15);
		grid.setHgap(15);
		
		//image
//		Image image1 = new Image("my/res/Sankabuh.png");
//		ImageView img1View = new ImageView(); 
//		img1View.setImage(image1); 
//		Rectangle2D viewportRect = new Rectangle2D(170, 80, 120, 300);
//		img1View.setViewport(viewportRect);
//		GridPane.setConstraints(img1View, 0, 0);
		

		//only-Text label
		Label KPtxt =new Label ("KP");
		GridPane.setConstraints(KPtxt, 0, 7);
		Label Atktxt =new Label ("Angriff");
		GridPane.setConstraints(Atktxt, 0, 8);
		Label Deftxt =new Label ("Verteidigung");
		GridPane.setConstraints(Deftxt, 0, 9);
		Label SAtktxt =new Label ("Sp.Ang");
		GridPane.setConstraints(SAtktxt, 0, 10);
		Label SDeftxt =new Label ("Sp.Ver");
		GridPane.setConstraints(SDeftxt, 0, 11);
		Label Inittxt =new Label ("Initiative");
		GridPane.setConstraints(Inittxt, 0, 12);

		Label ASbigtxt =new Label ("Artenspezifische-\nStärken");
		GridPane.setConstraints(ASbigtxt, 1, 5);
		Label AStxt =new Label ("AS");
		GridPane.setConstraints(AStxt, 1, 6);
		
		Label FPtxt =new Label ("FP");
		GridPane.setConstraints(FPtxt, 2, 6);
		
		Label ISbigtxt =new Label ("Individuelle-\nStärken");
		GridPane.setConstraints(ISbigtxt, 3, 5);
		Label IStxt =new Label ("IS");
		GridPane.setConstraints(IStxt, 3, 6);
		
		Label Resbigtxt =new Label ("Resultierende-\nWerte");
		GridPane.setConstraints(Resbigtxt, 5, 5);
		Label Statstxt =new Label ("Stats");
		GridPane.setConstraints(Statstxt, 5, 6);
		
		Label Pkmntxt =new Label ("Pokemon:");
		GridPane.setConstraints(Pkmntxt, 6, 0);
		Label lvltxt =new Label ("Level:");
		GridPane.setConstraints(lvltxt, 6, 1);
		Label Wesentxt =new Label ("Wesen:");
		GridPane.setConstraints(Wesentxt, 6, 2);
		
		
		//Input txtTextfelder
		TextField pkmnInput = new TextField();
		pkmnInput.setPromptText("Tectass");
		GridPane.setConstraints(pkmnInput, 7, 0);
		
		TextField lvlInput = new TextField();
		lvlInput.setPromptText("50");
		GridPane.setConstraints(lvlInput, 7, 1);
		
		TextField wesenInput = new TextField();
		wesenInput.setPromptText("Neutral");
		GridPane.setConstraints(wesenInput, 7, 2);
		

		//Input nbTextfelder
		TextField FP_HPnb = new TextField();
		FP_HPnb.setPromptText("252");
		GridPane.setConstraints(FP_HPnb, 2, 7);
		TextField FP_Atknb = new TextField();
		FP_Atknb.setPromptText("252");
		GridPane.setConstraints(FP_Atknb, 2, 8);
		TextField FP_Defnb = new TextField();
		FP_Defnb.setPromptText("252");
		GridPane.setConstraints(FP_Defnb, 2, 9);
		TextField FP_SAtknb = new TextField();
		FP_SAtknb.setPromptText("252");
		GridPane.setConstraints(FP_SAtknb, 2, 10);
		TextField FP_SDefnb = new TextField();
		FP_SDefnb.setPromptText("252");
		GridPane.setConstraints(FP_SDefnb, 2, 11);
		TextField FP_Initnb = new TextField();
		FP_Initnb.setPromptText("252");
		GridPane.setConstraints(FP_Initnb, 2, 12);
		
		TextField IS_HPnb = new TextField();
		IS_HPnb.setPromptText("31");
		GridPane.setConstraints(IS_HPnb, 3, 7);
		TextField IS_Atknb = new TextField();
		IS_Atknb.setPromptText("31");
		GridPane.setConstraints(IS_Atknb, 3, 8);
		TextField IS_Defnb = new TextField();
		IS_Defnb.setPromptText("31");
		GridPane.setConstraints(IS_Defnb, 3, 9);
		TextField IS_SAtknb = new TextField();
		IS_SAtknb.setPromptText("31");
		GridPane.setConstraints(IS_SAtknb, 3, 10);
		TextField IS_SDefnb = new TextField();
		IS_SDefnb.setPromptText("31");
		GridPane.setConstraints(IS_SDefnb, 3, 11);
		TextField IS_Initnb = new TextField();
		IS_Initnb.setPromptText("31");
		GridPane.setConstraints(IS_Initnb, 3, 12);
		
		TextField VGnb = new TextField();
		VGnb.setPromptText("'-3','0','3'");
		GridPane.setConstraints(VGnb, 3, 1);
		
		
		Label AS_HPnb =new Label ("0");
		GridPane.setConstraints(AS_HPnb, 1, 7);
		Label AS_Atknb =new Label ("0");
		GridPane.setConstraints(AS_Atknb, 1, 8);
		Label AS_Defnb =new Label ("0");
		GridPane.setConstraints(AS_Defnb, 1, 9);
		Label AS_SAtknb =new Label ("0");
		GridPane.setConstraints(AS_SAtknb, 1,10);
		Label AS_SDefnb =new Label ("0");
		GridPane.setConstraints(AS_SDefnb, 1,11);
		Label AS_Initnb =new Label ("0");
		GridPane.setConstraints(AS_Initnb, 1,12);
		
		
		//Output Data		
		Label res_HPnb =new Label (""+res_HP);
		GridPane.setConstraints(res_HPnb, 5, 7);
		Label res_Atknb =new Label (""+res_Atk);
		GridPane.setConstraints(res_Atknb, 5, 8);
		Label res_Defnb =new Label (""+res_Def);
		GridPane.setConstraints(res_Defnb, 5, 9);
		Label res_SAtknb =new Label (""+res_SAtk);
		GridPane.setConstraints(res_SAtknb, 5,10);
		Label res_SDefnb =new Label (""+res_SDef);
		GridPane.setConstraints(res_SDefnb, 5,11);
		Label res_Initnb =new Label (""+res_Init);
		GridPane.setConstraints(res_Initnb, 5,12);
		
		Label FP_usable =new Label ("Fleißpunkte\nverfügbar: "+(lvl*10));
		GridPane.setConstraints(FP_usable, 2, 5);
		
		
		
		Label txtOutput =new Label ("Zum kopieren:");
		GridPane.setConstraints(txtOutput, 0, 14);
		
		TextField txtCopyOutput = new TextField ();
		GridPane.setConstraints(txtCopyOutput, 1, 14);
		txtCopyOutput.setPromptText("{0,0,0,0,0,0}");

		//Button
		Button setFPmax = new Button("Max FP");
		GridPane.setConstraints(setFPmax, 2, 1);
		setFPmax.setOnAction(e ->{
			FP_HPnb.setText("252");
			FP_Atknb.setText("252");
			FP_Defnb.setText("252");
			FP_SAtknb.setText("252");
			FP_SDefnb.setText("252");
			FP_Initnb.setText("252");
		});
		
		Button setFPmin = new Button("Min FP");
		GridPane.setConstraints(setFPmin, 2, 2);
		setFPmin.setOnAction(e ->{
			FP_HPnb.setText("0");
			FP_Atknb.setText("0");
			FP_Defnb.setText("0");
			FP_SAtknb.setText("0");
			FP_SDefnb.setText("0");
			FP_Initnb.setText("0");
		});
		
		Button randomIS = new Button("Random IS");
		GridPane.setConstraints(randomIS, 3, 2);
		randomIS.setOnAction(e ->{
			switch (VGnb.getText()) {
			case "1":	IS_HPnb.setText(""+IS_random_VG1());
						IS_Atknb.setText(""+IS_random_VG1());
						IS_Defnb.setText(""+IS_random_VG1());
						IS_SAtknb.setText(""+IS_random_VG1());
						IS_SDefnb.setText(""+IS_random_VG1());
						IS_Initnb.setText(""+IS_random_VG1());
						break;
					
			case "2":	IS_HPnb.setText(""+IS_random_VG2());
						IS_Atknb.setText(""+IS_random_VG2());
						IS_Defnb.setText(""+IS_random_VG2());
						IS_SAtknb.setText(""+IS_random_VG2());
						IS_SDefnb.setText(""+IS_random_VG2());
						IS_Initnb.setText(""+IS_random_VG2());
						break;
					
			case "3":	IS_HPnb.setText(""+IS_random_VG3());
						IS_Atknb.setText(""+IS_random_VG3());
						IS_Defnb.setText(""+IS_random_VG3());
						IS_SAtknb.setText(""+IS_random_VG3());
						IS_SDefnb.setText(""+IS_random_VG3());
						IS_Initnb.setText(""+IS_random_VG3());
						break;
					
			case "-1":	IS_HPnb.setText(""+IS_random_VGneg1());
						IS_Atknb.setText(""+IS_random_VGneg1());
						IS_Defnb.setText(""+IS_random_VGneg1());
						IS_SAtknb.setText(""+IS_random_VGneg1());
						IS_SDefnb.setText(""+IS_random_VGneg1());
						IS_Initnb.setText(""+IS_random_VGneg1());
						break;
					
			case "-2":	IS_HPnb.setText(""+IS_random_VGneg2());
						IS_Atknb.setText(""+IS_random_VGneg2());
						IS_Defnb.setText(""+IS_random_VGneg2());
						IS_SAtknb.setText(""+IS_random_VGneg2());
						IS_SDefnb.setText(""+IS_random_VGneg2());
						IS_Initnb.setText(""+IS_random_VGneg2());
						break;
					
			case "-3":	IS_HPnb.setText(""+IS_random_VGneg3());
						IS_Atknb.setText(""+IS_random_VGneg3());
						IS_Defnb.setText(""+IS_random_VGneg3());
						IS_SAtknb.setText(""+IS_random_VGneg3());
						IS_SDefnb.setText(""+IS_random_VGneg3());
						IS_Initnb.setText(""+IS_random_VGneg3());
						break;
					
			default:	IS_HPnb.setText(""+IS_random_VG0());
						IS_Atknb.setText(""+IS_random_VG0());
						IS_Defnb.setText(""+IS_random_VG0());
						IS_SAtknb.setText(""+IS_random_VG0());
						IS_SDefnb.setText(""+IS_random_VG0());
						IS_Initnb.setText(""+IS_random_VG0());
						break;
			}

		});
		Button loadB = new Button("Load");
		GridPane.setConstraints(loadB, 5, 0);
		loadB.setOnAction(e ->{
			for (int i = 0; i < Pkmn_Liste_Import.name.length; i++) {
				if (pkmnInput.getText().equals(Pkmn_Liste_Import.name[i])) {
					
					AS_HP = Pkmn_Liste_Import.stats[i][0];
					AS_Atk = Pkmn_Liste_Import.stats[i][1];
					AS_Def = Pkmn_Liste_Import.stats[i][2];
					AS_SAtk = Pkmn_Liste_Import.stats[i][3];
					AS_SDef = Pkmn_Liste_Import.stats[i][4];
					AS_Init = Pkmn_Liste_Import.stats[i][5];
				}
			}
			AS_HPnb.setText(""+AS_HP);
			AS_Atknb.setText(""+AS_Atk);
			AS_Defnb.setText(""+AS_Def);
			AS_SAtknb.setText(""+AS_SAtk);
			AS_SDefnb.setText(""+AS_SDef);
			AS_Initnb.setText(""+AS_Init);

		int lvl = intfromTextField(lvlInput);
		
		int FP_HP = intfromTextField(FP_HPnb);
		int FP_Atk = intfromTextField(FP_Atknb);
		int FP_Def = intfromTextField(FP_Defnb);
		int FP_SAtk = intfromTextField(FP_SAtknb);
		int FP_SDef = intfromTextField(FP_SDefnb);
		int FP_Init = intfromTextField(FP_Initnb);
		
		int IS_HP = intfromTextField(IS_HPnb);
		int IS_Atk = intfromTextField(IS_Atknb);
		int IS_Def = intfromTextField(IS_Defnb);
		int IS_SAtk = intfromTextField(IS_SAtknb);
		int IS_SDef = intfromTextField(IS_SDefnb);
		int IS_Init = intfromTextField(IS_Initnb);
		
		//offizielle Formel	
		double calc_HP = Math.floor((((2 * AS_HP + IS_HP + Math.floor(FP_HP / 4)) * lvl) / 100) + lvl + 10);
		double calc_Atk = Math.floor((((2 * AS_Atk + IS_Atk + Math.floor(FP_Atk / 4)) * lvl) / 100) + 5);
		double calc_Def = Math.floor((((2 * AS_Def + IS_Def + Math.floor(FP_Def / 4)) * lvl) / 100) + 5);
		double calc_SAtk = Math.floor((((2 * AS_SAtk + IS_SAtk + Math.floor(FP_SAtk / 4)) * lvl) / 100) + 5);
		double calc_SDef = Math.floor((((2 * AS_SDef + IS_SDef + Math.floor(FP_SDef / 4)) * lvl) / 100) + 5);
		double calc_Init = Math.floor((((2 * AS_Init + IS_Init + Math.floor(FP_Init / 4)) * lvl) / 100) + 5);
		
		res_HP = (int) calc_HP;
		res_Atk = (int) calc_Atk;
		res_Def = (int) calc_Def;
		res_SAtk = (int) calc_SAtk;
		res_SDef = (int) calc_SDef;
		res_Init = (int) calc_Init;
		
		switch (wesenInput.getText()) {

		case "Solo":
			res_Atk = (int) Math.floor(calc_Atk * 1.1);
			res_Def = (int) Math.floor(calc_Def * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Atk>Def");
			break;
		case "Hart":
			res_Atk = (int) Math.floor(calc_Atk * 1.1);
			res_SAtk = (int) Math.floor(calc_SAtk * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Atk>SAtk");
			break;
		case "Frech":
			res_Atk = (int) Math.floor(calc_Atk * 1.1);
			res_SDef = (int) Math.floor(calc_SDef * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Atk>SDef");
			break;
		case "Mutig":
			res_Atk = (int) Math.floor(calc_Atk * 1.1);
			res_Init = (int) Math.floor(calc_Init * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Atk>Init");
			break;

		case "Kühn":
			res_Def = (int) Math.floor(calc_Def * 1.1);
			res_Atk = (int) Math.floor(calc_Atk * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Def>Atk");
			break;
		case "Pfiffig":
			res_Def = (int) Math.floor(calc_Def * 1.1);
			res_SAtk = (int) Math.floor(calc_SAtk * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Def>SAtk");
			break;
		case "Lasch":
			res_Def = (int) Math.floor(calc_Def * 1.1);
			res_SDef = (int) Math.floor(calc_SDef * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Def>SDef");
			break;
		case "Locker":
			res_Def = (int) Math.floor(calc_Def * 1.1);
			res_Init = (int) Math.floor(calc_Init * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. Def>Init");
			break;

		case "Mäßig":
			res_SAtk = (int) Math.floor(calc_SAtk * 1.1);
			res_Atk = (int) Math.floor(calc_Atk * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. SAtk>Atk");
			break;
		case "Mild":
			res_SAtk = (int) Math.floor(calc_SAtk * 1.1);
			res_Def = (int) Math.floor(calc_Def * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. SAtk>Def");
			break;
		case "Hitzig":
			res_SAtk = (int) Math.floor(calc_SAtk * 1.1);
			res_SDef = (int) Math.floor(calc_SDef * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. SAtk>SDef");
			break;
		case "Ruhig":
			res_SAtk = (int) Math.floor(calc_SAtk * 1.1);
			res_Init = (int) Math.floor(calc_Init * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. SAtk>Init");
			break;

		case "Still":
			res_SDef = (int) Math.floor(calc_SDef * 1.1);
			res_Atk = (int) Math.floor(calc_Atk * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. SDef>Atk");
			break;
		case "Zart":
			res_SDef = (int) Math.floor(calc_SDef * 1.1);
			res_Def = (int) Math.floor(calc_Def * 0.9);
			System.out.println("Wesen '" + wesenInput + "' wurde ausgewählt. SDef>Def");
			break;
		case "Sacht":
			res_SDef = (int) Math.floor(calc_SDef * 1.1);
			res_SAtk = (int) Math.floor(calc_SAtk * 0.9);
			break;
		case "Forsch":
			res_SDef = (int) Math.floor(calc_SDef * 1.1);
			res_Init = (int) Math.floor(calc_Init * 0.9);
			break;

		case "Scheu":
			res_Init = (int) Math.floor(calc_Init * 1.1);
			res_Atk = (int) Math.floor(calc_Atk * 0.9);
			break;
		case "Hastig":
			res_Init = (int) Math.floor(calc_Init * 1.1);
			res_Def = (int) Math.floor(calc_Def * 0.9);
			break;
		case "Froh":
			res_Init = (int) Math.floor(calc_Init * 1.1);
			res_SAtk = (int) Math.floor(calc_SAtk * 0.9);
			break;
		case "Naiv":
			res_Init = (int) Math.floor(calc_Init * 1.1);
			res_SDef = (int) Math.floor(calc_SDef * 0.9);
			break;

		default:
			break;
		}
		res_HPnb.setText(""+res_HP);
		res_Atknb.setText(""+res_Atk);
		res_Defnb.setText(""+res_Def);
		res_SAtknb.setText(""+res_SAtk);
		res_SDefnb.setText(""+res_SDef);
		res_Initnb.setText(""+res_Init);
		
		txtCopyOutput.setText("{"+res_HP+","+res_Atk+","+res_Def+","+res_SAtk+","+res_SDef+","+res_Init+"}");
		FP_usable.setText("Fleißpunkte\nverfügbar: "+(lvl*10-FP_HP-FP_Atk-FP_Def-FP_SAtk-FP_SDef-FP_Init));
		});

		

		
		
		
		grid.getChildren().addAll(
/*only-Text label*/	KPtxt, Atktxt, Deftxt,SAtktxt,SDeftxt,Inittxt, ASbigtxt,AStxt,FPtxt,ISbigtxt,IStxt,
/*only-Text label*/ Resbigtxt,Statstxt, Pkmntxt, lvltxt, Wesentxt, txtOutput,
/*InputTextfelder*/ pkmnInput,lvlInput,wesenInput, FP_HPnb, FP_Atknb,FP_Defnb,FP_SAtknb,FP_SDefnb,FP_Initnb,IS_HPnb,IS_Atknb,IS_Defnb,IS_SAtknb,IS_SDefnb,IS_Initnb,VGnb,
/*Buttons*/			loadB,setFPmax,setFPmin,randomIS,
/*Output Data*/		AS_HPnb,AS_Atknb,AS_Defnb,AS_SAtknb,AS_SDefnb,AS_Initnb,res_HPnb,res_Atknb,res_Defnb,res_SAtknb,res_SDefnb,res_Initnb,txtCopyOutput, FP_usable
///*Image*/			,img1View
					);
		
		
		
		
		
		Scene scene =new Scene(grid, 920, 550);
		
		
		window.setScene(scene);
		window.show();
		


	
	}
	public static int IS_random_VG0() {
		return (int) Math.round(31 * Math.random());
	}

	public static int IS_random_VG1() {
		int sample1 = (int) Math.round(31 * Math.random());
		int sample2 = (int) Math.round(31 * Math.random());
		if (sample1 > sample2)
			return sample1;
		else
			return sample2;

	}
	
	public static int IS_random_VG2() {
		int sample1 = (int) Math.round(31 * Math.random());
		int sample2 = (int) Math.round(31 * Math.random());
		int sample3 = (int) Math.round(31 * Math.random());
		if ((sample1 > sample2) && (sample1 > sample3))
			return sample1;
		else if ((sample2 > sample1) && (sample2 > sample3))
			return sample2;
		else
			return sample3;

		
	}

	public static int IS_random_VG3() {
		int sample1 = (int) Math.round(31 * Math.random());
		int sample2 = (int) Math.round(31 * Math.random());
		if ((sample1 > sample2) && (sample1 > 10))
			return sample1;
		else if ((sample2 > sample1) && (sample2 > 10))
			return sample2;
		else
			return 31;
	}
	
	public static int IS_random_VGneg1() {
		int sample1 = (int) Math.round(31 * Math.random());
		int sample2 = (int) Math.round(31 * Math.random());
		if (sample1 < sample2)
			return sample1;
		else
			return sample2;
		
	}
	
	public static int IS_random_VGneg2() {
		int sample1 = (int) Math.round(31 * Math.random());
		int sample2 = (int) Math.round(31 * Math.random());
		int sample3 = (int) Math.round(31 * Math.random());
		if ((sample1 < sample2) && (sample1 < sample3))
			return sample1;
		else if ((sample2 < sample1) && (sample2 < sample3))
			return sample2;
		else
			return sample3;
		
		
	}
	
	public static int IS_random_VGneg3() {
		int sample1 = (int) Math.round(31 * Math.random());
		int sample2 = (int) Math.round(31 * Math.random());
		if ((sample1 < sample2) && (sample1 < 20))
			return sample1;
		else if ((sample2 < sample1) && (sample2 < 20))
			return sample2;
		else
			return 0;
	}
	public static int intfromTextField(TextField input) {
		int sample;
		try { 
			sample = Integer.parseInt(input.getText());
		} catch (NumberFormatException e) {
			sample = 0;
		}
		return sample;
	}
}

















