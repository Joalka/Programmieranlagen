package StatCalc;

import PkmnObjekt.CustomComplexPkmn;

public class test {

	public static void main(String[] args) {
		CustomComplexPkmn cp1 = new CustomComplexPkmn("Robin",18,Pkmn_Liste_Import.stats[657],"Flug","Feuer","Flammkörper");
		cp1.setAbility(1,"H2O-Absorber");
		cp1.setName("Leeeeroy Jeeeeenkins!");
		
		cp1.writeReport();

	}

}
