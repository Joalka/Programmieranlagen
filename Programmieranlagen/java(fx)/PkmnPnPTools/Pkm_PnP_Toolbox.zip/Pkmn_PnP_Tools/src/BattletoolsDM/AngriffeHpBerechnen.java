package BattletoolsDM;
import java.util.Scanner;

public class AngriffeHpBerechnen {

	public static void main(String[] args) {

		int[] max_HP = new int[Daten_Kampfteilnehmer.Teilnehmer.length];
		for (int i = 0; i < Daten_Kampfteilnehmer.Teilnehmer.length; i++) {
			max_HP[i] = 10 * Daten_Kampfteilnehmer.Stats[i][0];
		}
		System.out.println("Teilnehmer(fullHP):");
		for (int i = 0; i < max_HP.length; i++) {
			System.out.println(Daten_Kampfteilnehmer.Teilnehmer[i] + ":  \t" + max_HP[i]);
		}
		System.out.println("\n\nEs greift an:");
		String Input_Teilnehmer = Scan_String();
		
		String Angreifer = "";
		String Verteidiger = "";
		boolean foundAttacker = false;
		boolean foundDefender = false;
		boolean SpezAtk = false;
		int power = 0;
		int Atk_stat =0;
		int Def_stat =0;
		double dmg_mult = 1;
		int dmg = 0;
		boolean done = false;

		while (!foundAttacker) {
			for (int i = 0; i < Daten_Kampfteilnehmer.Teilnehmer.length; i++) {
				if (Input_Teilnehmer.equals(Daten_Kampfteilnehmer.Teilnehmer[i])) {
					foundAttacker = true;
					Angreifer = Input_Teilnehmer;
					
					System.out.println("Angriffsart?\t 1. Physisch");
					System.out.println("\t\t 2. Spezial");

					String Input_AtkType = Scan_String();
					switch (Input_AtkType) {
					case "S":
					case "s":
					case "Sp":
					case "SP":
					case "Spez":
					case "spez":
					case "Spezial":
					case "SPEZIAL":
					case "2":
						SpezAtk = true;
						break;
					}
					if (SpezAtk) {
						Atk_stat = Daten_Kampfteilnehmer.Stats[i][3];
					}
					else {
						Atk_stat = Daten_Kampfteilnehmer.Stats[i][1];
					}
					
					System.out.println("Movepower:");
					power = Scan_int();

					System.out.print(Angreifer + " greift ");
					if (SpezAtk) {
						System.out.print("speziell");
					} else {
						System.out.print("physisch");
					}
					System.out.println(" mit Stärke " + power + " und Atk "+ Atk_stat + " an.");
				}
			}
			if (!foundAttacker) {
				System.out.println("Es konnte kein Teilnehmer unter dem Namen <" + Input_Teilnehmer + "> gefunden werden");
				System.out.println("Versuchs nochmal\n\n");
				System.out.println("\n\nEs greift an:");
				Input_Teilnehmer = Scan_String();
			}
		}
		System.out.println("\n\nEs wird getroffen:");
		Input_Teilnehmer = Scan_String();
		do {
			while (!foundDefender) {
				for (int i = 0; i < Daten_Kampfteilnehmer.Teilnehmer.length; i++) {
					if (Input_Teilnehmer.equals(Daten_Kampfteilnehmer.Teilnehmer[i])) {
						foundDefender=true;
						Verteidiger = Input_Teilnehmer;
						if (SpezAtk) {
							Def_stat = Daten_Kampfteilnehmer.Stats[i][4];
						}
						else {
							Def_stat = Daten_Kampfteilnehmer.Stats[i][2];
						}
					}
				}
				if (!foundDefender) {
					System.out.println("Es konnte kein Teilnehmer unter dem Namen <" + Input_Teilnehmer + "> gefunden werden");
					System.out.println("Versuchs nochmal\n\n");
					System.out.println("\n\nEs wird getroffen:");
					Input_Teilnehmer = Scan_String();
				}
				System.out.println("Gib den Damage Multiplikator an:");
				System.out.println("(Schwächen, Resistenzen, teilweise ausgewichen?)");
				dmg_mult = Scan_double();
				
				System.out.println(Angreifer+" mit \t(S)Atk: "+Atk_stat+",\tMovepower "+power+" greift");
				System.out.println(Verteidiger+" mit \t(S)Def: "+Def_stat+",\tMultiplikator "+dmg_mult+" an");
				dmg = calc_dmg(Atk_stat, power, Def_stat, dmg_mult);
				System.out.println(Verteidiger+" erhält "+dmg+" HP Schaden");
			
			}
			System.out.println("\n\nSoll derselbe Angriff noch ein weiteres Ziel treffen?(y/n)");
			done = !Scan_yn();
			if (!done) {
				foundDefender = false;
				System.out.println("\n\nEs wird getroffen:");
				Input_Teilnehmer = Scan_String();
			}
			
		}while (!done) ;
	}

	public static int Scan_int() {
		int nb;
		String txt = Scan_String();
		if (txt == "")
			return nb = 0;
		else
			return nb = Integer.parseInt(txt);
	}

	public static double Scan_double() {
		double nb;
		String txt = Scan_String();
		if (txt == "")
			return nb = 1;
		else
			return nb = Double.parseDouble(txt);
	}

	public static String Scan_String() {
		Scanner input = new Scanner(System.in);
		String txt = input.nextLine();
		return txt;
	}
	public static boolean Scan_yn() {
		String input = "";
		while (((!input.equals("y")) && (!input.equals("Y")) && (!input.equals("n")) && (!input.equals("N")))) {
		input = Scan_String();
		}
		if (input.equals("y") || (input.equals("Y")))
			return true;
		else 
			return false;
	}

	public static int calc_dmg (int Atk, int power, int Def, double mult){
		int dmg;
		double step1 = (double)Atk/Def;
		return dmg = (int)Math.round(step1 * power * mult);
	}
}
