package BattletoolsDM;

public class Daten_Kampfteilnehmer {
	
	public static String 	[] Teilnehmer = {"Rattfratz"			,"Relaxo"				,"Vulpix"				,"Sankabuh"				,"Skaraborn"			,"Emolga"				,"Glurak"			,"Tectass"					,"Guardevoire", 				"Botogel"				,"Gallopa"		,"Platzhalter"		, "Platzhalter"		, "Platzhalter"		,"Platzhalter"};
	public static int [][] Stats = 		{{54,36,27,26,28,66}	,{137,68,41,44,69,27}	,{63,34,33,55,46,47}	,{61,38,47,43,47,34}	,{80,94,48,33,57,57}	,{70,51,38,56,39,71}	,{82,79,53,61,56,63},{255,286,282,148,207,135}	,{234,108,114,228,175,157},		{50,30,20,60,70,100},	{164,133,112,125,139,155},		{0,0,0,0,0,0},		{0,0,0,0,0,0},		{0,0,0,0,0,0}, 		{0,0,0,0,0,0}};
								//	{HP,Atk,Def,SAtk,SDef,Init}	nächstes mal mit Enum
	
}
