package BattletoolsDM;

import StatCalc.Pkmn_Liste_Import;
import java.util.Scanner;
public class Initmap {

	public static void main(String[] args) {
		
		int [] Initiative = new int [Daten_Kampfteilnehmer.Teilnehmer.length];
		for (int j = 0; j < Daten_Kampfteilnehmer.Teilnehmer.length; j++) {
			Initiative[j] = Daten_Kampfteilnehmer.Stats[j][5];
		}
		double [] init_token = new double [Daten_Kampfteilnehmer.Teilnehmer.length];
		int [] playcount  = new int [Daten_Kampfteilnehmer.Teilnehmer.length];
		int Mindestzuganzahl = 100;
		int controle = 30 * get_maxwert(Initiative);
		int T;
		
		
		String	[] Comment = new String [Daten_Kampfteilnehmer.Teilnehmer.length];
		for (int i = Comment.length - 1; i >= 0; i--) { 
			Comment[i] = "";
		}
		
		int	[] original_Init  = new int [Initiative.length];
		for (int i = original_Init.length - 1; i >= 0; i--) { 
			original_Init[i] = Initiative[i];
		}
		
		
		
		
		if(Daten_Kampfteilnehmer.Teilnehmer.length != Initiative.length)
			System.out.println("!!!Es gibt unterschiedlich viele Teilnehmer und Initiative-Werte!!!");
		else 	{
			for (int i = Daten_Kampfteilnehmer.Teilnehmer.length - 1; i >= 0; i--) {		
				System.out.println("T"+i+":"+Daten_Kampfteilnehmer.Teilnehmer[i] + ":  \t" + Initiative[i] + " Initiative");
				init_token[i] = get_init_to_token(Initiative[i]);
			}
			System.out.println("\nBefehle: TX\t-> Comment add");
			System.out.println("\t\t-> Comment del");
			System.out.println("\t\t-> Comment new");
			System.out.println("\t\t-> Init\t\t-> += -> (X)");
			System.out.println("\t\t\t\t-> -= -> (X)");
			System.out.println("\t\t\t\t-> *= -> (X)oder(X.x)");
			System.out.println("\t\t\t\t-> /= -> (X)oder(X.x)");
			System.out.println("\t\t\t\t->  = -> (X)");
			System.out.println("\t\t\t\t->  reset");
			System.out.println("\t\t-> skip\t\t-> (X)oder(X.x)");
			
			System.out.println("Initmap startet hier:");
			System.out.println("-----------------------------------------------");
			
		
			double min_token = get_minwert(init_token);
			System.out.println();
		
			
			for (int turn = 0; turn < controle / min_token * Mindestzuganzahl; turn++) {
				for (int i = 0;i < Daten_Kampfteilnehmer.Teilnehmer.length;i++) { 
					init_token[i] += get_init_to_token(Initiative[i]);
					if (init_token[i] > controle) {
						init_token[i] -= controle;
						playcount[i]++;
						System.out.println("\nZyklus:" + turn + "\t Move:" + playcount[i] + " \tT" + i+": " + Daten_Kampfteilnehmer.Teilnehmer[i]+"\n\t\t\t\t"+Comment[i]);
						
						T=-1;
						String Befehleingabe = Scan_String();		//für langsame Liste
						switch (Befehleingabe) {
						case "T0":  T=0;	break;
						case "T1":  T=1;	break;
						case "T2":  T=2;	break;
						case "T3":  T=3;	break;
						case "T4":  T=4;	break;
						case "T5":  T=5;	break;
						case "T6":  T=6;	break;
						case "T7":  T=7;	break;
						case "T8":  T=8;	break;
						case "T9":  T=9;	break;
						}
						if(T!=-1) {
							System.out.println("Gib einen Befehl für "+Daten_Kampfteilnehmer.Teilnehmer[T]+" ein:");
							String Befehl = Scan_String();
						
						switch (Befehl) {
						case "Comment add": 
							System.out.println("Folgender Kommentar wird "+Daten_Kampfteilnehmer.Teilnehmer[T]+" hinzugefügt:");
							Comment[T] += Scan_String()+"\n\t\t\t\t"; break;
						case "Comment del": Comment[T] = "";	break;
						case "Comment new":
							System.out.println("Kommentare für "+Daten_Kampfteilnehmer.Teilnehmer[T]+":\t"+Comment[T]);
							System.out.println("wurden gelöscht. Gib nun den neuen Kommentar ein:");
							Comment[T] = Scan_String()+"\n\t\t\t\t"; 
							break;
						case "Init":
							System.out.println("Die Initiative von "+Daten_Kampfteilnehmer.Teilnehmer[T]+" wird angepasst.");
							System.out.println("Wähle einen Operator: 	1. += (X)");
							System.out.println("                        2. -= (X)");
							System.out.println("                        3. *= (X)oder(X.x)");
							System.out.println("                        4. /= (X)oder(X.x)");
							System.out.println("                        5.  = (X)");
							System.out.println("                        6.  reset");
							int operator = Scan_int();
							System.out.println("Du hast "+operator+". gewählt. Zahleneingabe:");
							double mod = 0;
							if (operator !=6) {
							mod = Scan_double();
							}
							switch (operator) {
							case 1: Initiative[T] += mod;	break;
							case 2: Initiative[T] -= mod;	break;
							case 3: Initiative[T] *= mod;	break;
							case 4: Initiative[T] /= mod;	break;
							case 5: Initiative[T] = (int)mod;	break;
							case 6: Initiative[T] = original_Init[T];	break;
 
							default:							break;
							} break;
							
						case "skip": 
							System.out.println(Daten_Kampfteilnehmer.Teilnehmer[T]+" muss aussetzen. Gib an wie viele Züge:");
							double skip_mod = Scan_double();
							init_token[T]-=(controle*skip_mod);
							System.out.println(Daten_Kampfteilnehmer.Teilnehmer[T]+" muss "+skip_mod+" Züge aussetzen\n");
							break;
							
						default: 
							break;
						}
						System.out.println("Zyklus:"+turn+"\tBericht: "+Daten_Kampfteilnehmer.Teilnehmer[T]);			
						System.out.println("\t\tInitiative:\t"+Initiative[T]+"\n\t\tKommentar:\t"+Comment[T]);		
						init_token[i]+=controle;
						playcount[i]--;
						i--;
						}
						
					}
				}
			}
		}
	}
	
	public static int Scan_int() {
		int nb;
		String txt = Scan_String();
		if (txt=="")
			return nb=0;
		else	
			return nb = Integer.parseInt(txt);
	}

	
	public static double Scan_double() {
		double nb;
		String txt = Scan_String();
		if (txt=="")
			return nb=0;
		else	
			return nb = Double.parseDouble(txt);
	}
	
	public static String Scan_String() {
		Scanner input = new Scanner(System.in);
		String txt = input.nextLine();
		return txt;
	}
	
	public static double get_minwert(double[]Array) {
		double minwert = Double.MAX_VALUE;
		for (int i =0; i<Array.length;i++) {
			if (minwert>Array[i]) {
				minwert = Array[i];
			}
		}
		return minwert;
	}
			
	public static int get_maxwert(int[]Array) {
		int maxwert =0;
		for (int i =0; i<Array.length;i++) {
			if (maxwert<Array[i]) {
				maxwert = Array[i];
			}
		}
		return maxwert;
	}
	
		
	
	public static double get_init_to_token(int Initiative) {
		return Math.sqrt(Initiative);
	}
}
