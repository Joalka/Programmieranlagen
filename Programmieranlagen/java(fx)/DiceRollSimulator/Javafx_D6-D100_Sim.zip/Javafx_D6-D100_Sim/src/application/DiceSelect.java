package application;
	
//import java.awt.Label;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.beans.binding.NumberBinding;



import javafx.scene.layout.BorderPane;

public class DiceSelect extends Application{
	
	
	Button b_reset; 
	Button b_D4; 
	Button b_D6; 
	Button b_D8;
	Button b_D10;
	Button b_D12;
	Button b_D20;
	Button b_D100;
	
	
	Button b_Roll;
	Button b_History;
	


	int cD4 =0;
	Label displayCD4 = new Label ("D4: " + cD4 + "\t\t");
	
	int cD6 =0;
	Label displayCD6 = new Label ("D6: " + cD6 + "\t\t");
	
	int cD8 =0;
	Label displayCD8 = new Label ("D8: " + cD8 + "\t\t");
	
	int cD10 =0;
	Label displayCD10 = new Label ("D10: " + cD10 + "\t\t");
	
	int cD12 =0;
	Label displayCD12 = new Label ("D12: " + cD12 + "\t\t");
	
	int cD20 =0;
	Label displayCD20 = new Label ("D20: " + cD20 + "\t\t");
	
	int cD100 =0;
	Label displayCD100 = new Label ("D100: " + cD100 + "\t\t");
	
	int result = 0;
	Label display_result = new Label("Result:");
	
	
	static String historie = "\n";
	
	
	//Window size
	int lenght =300;
	int height =400;

	Stage window;
	Scene scene;
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	@Override
	public void start(Stage primaryStage) throws Exception{
		
		window = primaryStage;
		Label questionTitle = new Label ("Wähle die Würfel, die du werfen möchtest");
		window.setTitle("Dice Roll Simulation");
		
		window.setOnCloseRequest(e->{
			e.consume();
			AskCloseProgram();
		});
		
		
		Label Dice_header = new Label (" Würfel:");
		
		Label Count_header = new Label ("Anzahl:\t\t");
		
		
		b_reset = new Button ("Reset");
		b_reset.setOnAction(e ->{
			cD4 = 0; 
			cD6 = 0;
			cD8 = 0;
			cD10 = 0;
			cD12 = 0;
			cD20 = 0;
			cD100 = 0;
			displayCD4.setText("D4: " + cD4 + "\t\t");
			displayCD6.setText("D6: " + cD6 + "\t\t");
			displayCD8.setText("D8: " + cD8 + "\t\t");
			displayCD10.setText("D10: " + cD10 + "\t\t");
			displayCD12.setText("D12: " + cD12 + "\t\t");
			displayCD20.setText("D20: " + cD20 + "\t\t");
			displayCD100.setText("D100: " + cD100 + "\t\t");
			show_count(cD4, cD6, cD8, cD10, cD12, cD20, cD100);
		});
		
		b_D4 = new Button ("D4");
		b_D4.setOnAction(e ->{
			cD4++;
			show_count(cD4,cD6,cD8,cD10,cD12,cD20,cD100);
			displayCD4.setText("D4: " + cD4 + "\t\t");
		});
		b_D6 = new Button ("D6");
		b_D6.setOnAction(e ->{
			cD6++;
			show_count(cD4,cD6,cD8,cD10,cD12,cD20,cD100);
			displayCD6.setText("D6: " + cD6 + "\t\t");
		});
		b_D8 = new Button ("D8");
		b_D8.setOnAction(e ->{
			cD8++;
			show_count(cD4,cD6,cD8,cD10,cD12,cD20,cD100);
			displayCD8.setText("D8: " + cD8 + "\t\t");
		});
		b_D10 = new Button ("D10");
		b_D10.setOnAction(e ->{
			cD10++;
			show_count(cD4,cD6,cD8,cD10,cD12,cD20,cD100);
			displayCD10.setText("D10: " + cD10 + "\t\t");
		});
		b_D12 = new Button ("D12");
		b_D12.setOnAction(e ->{
			cD12++;
			show_count(cD4,cD6,cD8,cD10,cD12,cD20,cD100);
			displayCD12.setText("D12: " + cD12 + "\t\t");
		});
		b_D20 = new Button ("D20");
		b_D20.setOnAction(e ->{
			cD20++;
			show_count(cD4,cD6,cD8,cD10,cD12,cD20,cD100);
			displayCD20.setText("D20: " + cD20 + "\t\t");
		});
		b_D100 = new Button ("D100");
		b_D100.setOnAction(e ->{
			cD100++;
			show_count(cD4,cD6,cD8,cD10,cD12,cD20,cD100);
			displayCD100.setText("D100: " + cD100 + "\t\t");
		});
		b_Roll = new Button ("Roll!");
		b_Roll.setOnAction(e ->{
			result = collapse_sum_dice(cD4, cD6, cD8, cD10, cD12, cD20, cD100);
			historie += "Result: " + String.valueOf(result) + "\n";
			show_count(cD4, cD6, cD8, cD10, cD12, cD20, cD100);
			display_result.setText("Result:" + result);
			System.out.println("Die Würfel sind gefallen!\nResult: " + result);
		});
		
		b_History = new Button ("History");
		b_History.setOnAction(e ->{
			history_presentation.display("","");
			
		});
		

		//Layout1 for children in vertical column
		VBox layoutDice_Buttons = new VBox(15);
		layoutDice_Buttons.getChildren().addAll(Dice_header, b_D4, b_D6, b_D8, b_D10, b_D12, b_D20, b_D100);
		
		HBox title = new HBox();
		title.getChildren().addAll(questionTitle);
		
		VBox action = new VBox(30);
		action.getChildren().addAll(b_Roll, display_result, b_reset);
		
		VBox layoutDice_count = new VBox(15);
		layoutDice_count.getChildren().addAll(Count_header, displayCD4, displayCD6, displayCD8, displayCD10, displayCD12, displayCD20, displayCD100);

		HBox options = new HBox(10);
		options.getChildren().addAll(b_History);
		
		BorderPane borderPane = new BorderPane();
		borderPane.setTop(title);
		borderPane.setLeft(layoutDice_Buttons);
		borderPane.setRight(layoutDice_count);
		borderPane.setCenter(action);
		borderPane.setBottom(options);

		
		scene = new Scene(borderPane, lenght, height);
		title.setAlignment(Pos.CENTER);
		layoutDice_Buttons.setAlignment(Pos.CENTER);
		layoutDice_count.setAlignment(Pos.CENTER);
		action.setAlignment(Pos.CENTER);
		options.setAlignment(Pos.CENTER);
		window.setScene(scene);
		
		window.show();
		
	}
	
	public static void show_count(int c1,int c2,int c3,int c4,int c5,int c6,int c7) {
		System.out.print("Selection:");
		if (c1>0)
			System.out.print("\tD4: " + c1);
		if (c2>0)
			System.out.print("\tD6: " + c2);
		if (c3>0)
			System.out.print("\tD8: " + c3);
		if (c4>0)
			System.out.print("\tD10: " + c4);
		if (c5>0)
			System.out.print("\tD12: " + c5);
		if (c6>0)
			System.out.print("\tD20: " + c6);
		if (c7>0)
			System.out.print("\tD100: " + c7);
		
		System.out.println();
	}
	
	public static int collapse_sum_dice(int D4,int D6,int D8,int D10,int D12,int D20,int D100) {
		int calculation = 0;
		for (int i=0; i<D4;i++) {
			calculation += get_random_1to(4);
		}
		for (int i=0; i<D6;i++) {
			calculation += get_random_1to(6);
		}
		for (int i=0; i<D8;i++) {
			calculation += get_random_1to(8);
		}
		for (int i=0; i<D10;i++) {
			calculation += get_random_1to(10);
		}
		for (int i=0; i<D12;i++) {
			calculation += get_random_1to(12);
		}
		for (int i=0; i<D20;i++) {
			calculation += get_random_1to(20);
		}
		for (int i=0; i<D100;i++) {
			calculation += get_random_1to(100);
		}
		return calculation;
		
	}
	public static int get_random_1to(int max) {
	int sample = (int) Math.ceil(max * Math.random());
	return sample;
	}
	
	private void AskCloseProgram() {
		boolean answer = ConfirmBox.display("Title", "Sure you wanna exit?");
		if (answer)
			window.close();
	}
}

	
		


	
	
	






































