package application;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;

public class history_presentation {

	
		public static void display(String title, String message) {
			
			

	 
	 
			Stage window = new Stage ();
			
			//Diese Klasse sperrt das Parent-window
			window.initModality(Modality.APPLICATION_MODAL);	
			window.setTitle("History");
			window.setMinWidth(250);
			window.setMaxHeight(650);
			
	
			
			
			Label label1 = new Label();
			label1.setText(DiceSelect.historie);
			
			Button closeButton = new Button("Close");
			closeButton.setOnAction(e->{
				window.close();
			});
			
			
			
			VBox layout1 = new VBox(30);
			layout1.getChildren().addAll(label1,closeButton);
			layout1.setAlignment(Pos.CENTER);
			
			Scene scene1 = new Scene(layout1);
			window.setScene(scene1);
			window.showAndWait();
		
			
			
		
		}
	

}
