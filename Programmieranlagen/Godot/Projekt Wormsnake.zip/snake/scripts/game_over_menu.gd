extends AnimatedSprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_reset_button_pressed() -> void:
	print("Gamereset initialising...")
	$"..".reset_game()

func _on_reset_button_button_down() -> void:
	$".".pause()

func _on_reset_button_button_up() -> void:
	$"../MusikTheme".play()
	$".".play()

func _on_quit_button_pressed() -> void:
	get_tree().quit()
