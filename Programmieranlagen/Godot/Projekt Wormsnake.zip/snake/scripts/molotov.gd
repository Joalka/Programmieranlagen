extends Area2D
@onready var macho_molotov: AnimatedSprite2D = $".."

const SPEED = 5/100
var being_thrown = false
var destination:Vector2
var path: Vector2


func _on_throw_molotov_timeout() -> void:
	$".".position = Vector2(0,0)
	destination = $"../Crosshair".position
	path = destination-$".".position
	being_thrown = true

func _on_gametick_timeout() -> void:
	if being_thrown and destination.distance_to($".".position)>10:
		$Molotov.visible = true
		print("Destination is at: "+ str(destination))
		print("Molotov is at: "+ str($".".position))
		print("distance: "+str(destination.distance_to($".".position)))
		$".".position += path/12
	elif being_thrown:
		$"../Crosshair".visible = false
		$Molotov.visible = false
		being_thrown = false
		$"../../../SoundEffekts/Explosion".play()
		$"..".set_fire()
		
func _process(delta: float) -> void:
	if being_thrown and destination.distance_to($".".position)>15:
		$Molotov.visible = true
		print("Destination is at: "+ str(destination))
		print("Molotov is at: "+ str($".".position))
		print("distance: "+str(destination.distance_to($".".position)))
		$".".position += (path*delta)/2
	elif being_thrown:
		$"../Crosshair".visible = false
		$Molotov.visible = false
		being_thrown = false
		$"../../../SoundEffekts/Explosion".play()
		$"..".set_fire()
