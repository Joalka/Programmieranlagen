extends Node

enum group {CULTISTS,REBELLS}

enum Cultist_NPC_id {naked_worm, cultist_default, cultist_horned, demon}
var Cultists_NPC_Power = {"naked_worm": 3, "cultist_default": 5, "cultist_horned":9, "demon": 15}
var Cultists_NPC_maxCount = {"naked_worm": 0, "cultist_default": 0, "cultist_horned":0, "demon": 0}
var Cultists_NPC_Count = {"naked_worm": 0, "cultist_default": 0, "cultist_horned":0, "demon": 0}
var CultistsSpawnOrder = []
var CultistsPresent = []

@onready var cultist_defaultV1_scene : PackedScene = preload("res://scenes/cultist_defaultV1.tscn")
@onready var cultist_defaultV2_scene : PackedScene = preload("res://scenes/cultist_defaultV2.tscn")
@onready var cultist_horned_scene : PackedScene = preload("res://scenes/cultist_horned.tscn")
@onready var naked_worm_scene : PackedScene = preload("res://scenes/naked_worm.tscn")

enum Rebells_NPC_id {naked_worm, cultist_default, cultist_horned, demon}
var Rebells_NPC_Power = {"naked_worm": 2, "worm_sign": 3, "emo_punk":5, "macho_worm": 10}
var Rebells_NPC_maxCount = {"naked_worm": 0, "worm_sign": 0, "emo_punk":0, "macho_worm": 0}
var Rebells_NPC_Count = {"naked_worm": 0, "worm_sign": 0, "emo_punk":0, "macho_worm": 0}
var RebellsSpawnOrder = []
var RebellsPresent = []

@onready var sign_band_worm_scene : PackedScene = preload("res://scenes/sign_band_worm.tscn")
@onready var sign_holding_worm_scene : PackedScene = preload("res://scenes/sign_holding_worm.tscn")


func _ready() -> void:
	print(Cultists_NPC_Count)
	while CultistsSpawnOrder.size() < 100:
		for unit in Cultists_NPC_Power:
			var luck_check = sqrt(randi()%250)
			if luck_check >= Cultists_NPC_Power[unit]:
				Cultists_NPC_maxCount[unit] += 1
				#print (unit)					#gibt die Namen
				#print (Cultists_NPC_Power[unit])#gibt die Zahlen
				CultistsSpawnOrder.insert(CultistsSpawnOrder.size(),unit)
	CultistsSpawnOrder.insert(0,"cultist_default")
	CultistsSpawnOrder.insert(0,"cultist_default")
	CultistsSpawnOrder.insert(0,"cultist_default")
	CultistsSpawnOrder.insert(0,"cultist_default")
	print (CultistsSpawnOrder)
	for unit in Cultists_NPC_maxCount:
		print("Wir haben "+ unit + ":" + str(Cultists_NPC_maxCount[unit]))

	while RebellsSpawnOrder.size() < 100:
		for unit in Rebells_NPC_Power:
			var luck_check = sqrt(randi()%150)
			if luck_check >= Rebells_NPC_Power[unit]:
				Rebells_NPC_maxCount[unit] += 1
				RebellsSpawnOrder.insert(RebellsSpawnOrder.size(),unit)
	print (RebellsSpawnOrder)
	for unit in Rebells_NPC_maxCount:
		print("Wir haben "+ unit + ":" + str(Rebells_NPC_maxCount[unit]))

func _on_gametick_timeout() -> void:
	pass
	
func check_crowd_spawns():
	var spawn_resource = $"../Stats".group_strenght[group.CULTISTS]
	var total_cultists = 0
	for unit in Cultists_NPC_Count:
		spawn_resource -= Cultists_NPC_Count[unit]*Cultists_NPC_Power[unit]
		total_cultists += Cultists_NPC_Count[unit]
	print("Spawn-resource:" +str(spawn_resource))
	print("total cultists:" +str(total_cultists))
	for unit in Cultists_NPC_Power:
		if Cultists_NPC_Power[CultistsSpawnOrder[total_cultists]]<=spawn_resource and CultistsSpawnOrder[total_cultists]==unit:
			spawn_unit_cultist(unit)
			
	spawn_resource = $"../Stats".group_strenght[group.REBELLS]
	var total_rebells = 0
	for unit in Rebells_NPC_Count:
		spawn_resource -= Rebells_NPC_Count[unit]*Rebells_NPC_Power[unit]
		total_rebells += Rebells_NPC_Count[unit]
	print("Spawn-resource:" +str(spawn_resource))
	print("total cultists:" +str(total_rebells))
	for unit in Rebells_NPC_Power:
		if Rebells_NPC_Power[RebellsSpawnOrder[total_rebells]]<=spawn_resource and RebellsSpawnOrder[total_rebells]==unit:
			spawn_unit_rebell(unit)

func spawn_unit_cultist(unit:String):
	Cultists_NPC_Count[unit]+=1
	if unit == "naked_worm":
		add_naked_worm_cultists()
	elif unit == "cultist_default":
		add_cultist_default()
	elif unit == "cultist_horned":
		add_cultist_horned()

func spawn_unit_rebell(unit:String):
	Rebells_NPC_Count[unit]+=1
	if unit == "naked_worm":
		add_naked_worm_rebells()
	elif unit == "worm_sign":
		add_worm_sign()
	#elif unit == "cultist_horned":
		#add_cultist_horned()

func add_naked_worm_cultists():
	print("adding naked worm")
	var naked_worm_temp = naked_worm_scene.instantiate()
	naked_worm_temp.position = Vector2(randi_range(0,100),randi_range(0,130))
	$Cultists.add_child(naked_worm_temp)
	
func add_cultist_default():
	print("adding cultist default")
	var cultist_default_temp
	if randi()%1 == 0:
		cultist_default_temp = cultist_defaultV1_scene.instantiate()
	else:
		cultist_default_temp = cultist_defaultV2_scene.instantiate()
	cultist_default_temp.position = Vector2(randi_range(0,100),randi_range(0,130))
	$Cultists.add_child(cultist_default_temp)

func add_cultist_horned():
	print("adding cultist horned")
	var cultist_horned_temp = cultist_horned_scene.instantiate()
	cultist_horned_temp.position = Vector2(randi_range(0,100),randi_range(0,130))
	$Cultists.add_child(cultist_horned_temp)

func add_naked_worm_rebells():
	print("adding naked worm")
	var naked_worm_temp = naked_worm_scene.instantiate()
	naked_worm_temp.position = Vector2(randi_range(0,100),randi_range(0,130))
	$Rebells.add_child(naked_worm_temp)

func add_worm_sign():
	print("adding worm sign")
	var worm_sign_temp
	if randi()%1 == 0:
		worm_sign_temp = sign_band_worm_scene.instantiate()
	else:
		worm_sign_temp = sign_holding_worm_scene.instantiate()
	worm_sign_temp.position = Vector2(randi_range(0,100),randi_range(0,130))
	$Rebells.add_child(worm_sign_temp)

func form_demoncircle():
	var all_cultists = $".".get_child(0).get_children()
	var default_cultists
	for cultist in all_cultists:
		print (cultist) #cultistDefaultV1:<AnimatedSprite2D#75531028593>
		print (cultist.get_index()) #cultistDefaultV1:<AnimatedSprite2D#75531028593>
		if cultist.name == "cultistDefaultV1":
			print ("found cultist default V1")
		else:
			print ("couldnt find cultist default V1")

func clear_crowd():
	Cultists_NPC_Count = {"naked_worm": 0, "cultist_default": 0, "cultist_horned":0, "demon": 0}
	Rebells_NPC_Count = {"naked_worm": 0, "worm_sign": 0, "emo_punk":0, "macho_worm": 0}
	var all_cultist_sprites = $Cultists.get_children()
	for sprite in all_cultist_sprites:
		sprite.queue_free()
	var all_rebell_sprites = $Rebells.get_children()
	for sprite in all_rebell_sprites:
		sprite.queue_free()
