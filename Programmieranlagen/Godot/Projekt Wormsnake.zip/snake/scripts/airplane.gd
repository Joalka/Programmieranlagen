extends AnimatedSprite2D

var airplane_rdy = false
var airplane_destroyed = false
var time_per_flight = 40
var flight_duration = 12
var path: int #nur x-Koordinate
var is_rn_flying = false
var luck_check = 1
var destination = Vector2(-251,38)
#started bei x = 891
#up		-most destination = Vector2(-251,38)
#bottom	-most destination = Vector2(-251,322)




func try_flight():
	if airplane_rdy and !airplane_destroyed and !$".".visible and !is_rn_flying:
		if randi() %(time_per_flight) == luck_check:
			$".".visible = true
			$".".position.x = 891 #safety
			$".".position.y = randi_range(38,322) 
			is_rn_flying = true
			destination.x = -251 #safety
			destination.y = $".".position.y
			path = destination.x-$".".position.x

#func _on_gametick_timeout() -> void:
	#try_flight()
	#if is_rn_flying:
		#$".".position.x += path/flight_duration/4
	#if $".".position.x < -48:
		#is_rn_flying = false
		#$".".visible = false
		
func _process(delta: float) -> void:
	try_flight()
	if is_rn_flying:
		$".".position.x += path/flight_duration*delta
	if $".".position.x < -251:
		is_rn_flying = false
		$".".visible = false
