extends AnimatedSprite2D

var time_per_hack: int = 60 #in Sekunden
var luck_check: int = 1
var hack_active = false


func _on_gametick_timeout() -> void:
	if $".".visible == true:
		try_hacking()

func try_hacking():
	if $".".visible == true and randi() %(time_per_hack*4) == luck_check and hack_active == false:
		hack_active = true
		$Talking.visible = true
		$Hackduration.start()

func _on_hackduration_timeout() -> void:
	hack_active = false
	$Talking.visible = false
