extends Node

@onready var crowd: Node = $"../Crowd"
@onready var gametime_label: Label = $GametimeLabel
@onready var brewing_worm_wizard: AnimatedSprite2D = $"../Npc's/brewingWormWizard"
@onready var airplane: AnimatedSprite2D = $"../Npc's/Airplane"

var gametime: int = 0
var min: int = 0
func _on_gametimer_timeout():	#managed den Gametimer
	gametime += 1
	if gametime >= 60:
		min += 1
		gametime -=60
	if gametime >= 10:
		gametime_label.text = str(min)+":"+str(gametime)
	else:
		gametime_label.text = str(min)+":0"+str(gametime)

var food_eaten : int = 0
var player_lenght : int = 3

enum group {CULTISTS,REBELLS}

var group_strenght = [0,0]
var group_bonus = [0,0]

var highscore1 = [0,0,0]
var highscore2 = [0,0,0]
var highscore3 = [0,0,0]


func _process(delta: float) -> void:
	check_spawns()

func check_spawns():
	if group_strenght[group.CULTISTS] >= 10:
		$"../Npc's/brewingWormWizard".visible = true
		if $"../Crowd".Cultists_NPC_Count["cultist_default"]>=1:
			print("initiating form_demoncircle")
			$"../Crowd".form_demoncircle()
	if group_strenght[group.REBELLS] >= 15:
		$"../Npc's/MachoMolotov".visible = true
		if group_strenght[group.REBELLS] >= 25:
			$"../Npc's/Hackerworm".visible = true
			if group_strenght[group.REBELLS] >= 50:
				$"../Npc's/Airplane".airplane_rdy = true
		
	

func _input(event):				#Cheats
	#if Input.is_action_pressed("ui_accept"):
		#incre_foodcount()
	if Input.is_action_pressed("P"):
		$"../Npc's/brewingWormWizard".visible = true
		$"../Npc's/brewingWormWizard/floatingPotion".visible = true
	if Input.is_action_pressed("M"):
		$"../Npc's/MachoMolotov".visible = true
	if Input.is_action_pressed("F"):
		$"../Npc's/Airplane".airplane_rdy = true
		$"../Npc's/Airplane".time_per_flight = 10
		print("airplane activated with interval: " +str($"../Npc's/Airplane".time_per_flight)+ " seconds" )
	if Input.is_action_pressed("H"):
		$"../Npc's/Hackerworm".visible = true
		$"../Npc's/Hackerworm".time_per_hack = 15

func incre_foodcount():
	food_eaten +=1
	print("incre_foodcount to " + str(food_eaten))
	#print("increase cultists strenght:")
	increase_strenght(group.CULTISTS)
	#print("increase rebells strenght:")
	increase_strenght(group.REBELLS)
	$"../Crowd".check_crowd_spawns()
	update_score()

func increase_strenght(group):
	group_strenght[group]+=1+group_bonus[group]
	#print("increased "+ str(group)+ " to "+str(group_strenght[group]))

func get_player_lenght(worm_lenght):
	player_lenght=(worm_lenght+1)
	update_score()

func update_score():
	$WormsLabel.text=str(food_eaten)
	$LengthLabel.text=str(player_lenght)
	
func reset_score():
	manage_highscore([food_eaten,player_lenght,(gametime+(min*60))])
	food_eaten = 0
	group_strenght = [0,0]
	player_lenght = 3
	update_score()
	gametime = 0
	min = 0

func manage_highscore(new_score):
	var place = 0
	for i in highscore1.size():
		if new_score[i]>=highscore1[i]:
			place = 1 
			break
	for i in highscore2.size():
		if new_score[i]>=highscore2[i] and place == 0:
			place = 2
			break
	for i in highscore3.size():
		if new_score[i]>=highscore3[i] and place == 0:
			place = 3
			break
	if place == 1:
		highscore3 = highscore2
		highscore2 = highscore1
		highscore1 = new_score
	elif place == 2:
		highscore3 = highscore2
		highscore2 = new_score
	elif place == 3:
		highscore3 = new_score
	print_highscoreLabel()

func print_highscoreLabel():
	$highscore1Label.text = (str(highscore1[0]))+"e "+ (str(highscore1[1]))+"l "+(str(highscore1[2]))+"t "
	$highscore2Label.text = (str(highscore2[0]))+"e "+ (str(highscore2[1]))+"l "+(str(highscore2[2]))+"t "
	$highscore3Label.text = (str(highscore3[0]))+"e "+ (str(highscore3[1]))+"l "+(str(highscore3[2]))+"t "
