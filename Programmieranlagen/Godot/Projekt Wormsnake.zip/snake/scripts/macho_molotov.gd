extends AnimatedSprite2D
@onready var main_game: Node = $"../.."
@onready var fire: TileMapLayer = $"../../CharFood/Fire"
@onready var macho_molotov: AnimatedSprite2D = $"."
@onready var molotov: Area2D = $Molotov

var time_per_molotov: int = 20 #in Sekunden
var luck_check: int = 1
var crosshair_pos: Vector2i
var fire_pos: = [Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i()]
var fire_active = false

func _on_gametick_timeout() -> void:
	if $".".visible == true:
		try_throw_molotov()
		if fire_active:
			draw_fire()
		else:
			delete_fire()

func try_throw_molotov():
	if $Crosshair.visible == false and randi() %(time_per_molotov*4) == luck_check and !fire_active:
		crosshair_pos = $"../..".place_pickup()
		$Crosshair.position.x = crosshair_pos.x*16-$".".position.x+8
		$Crosshair.position.y = crosshair_pos.y*16-$".".position.y+8
		#$Crosshair.position.x = $"../..".worm_body[0].x*16-$".".position.x+8
		#$Crosshair.position.y = $"../..".worm_body[0].y*16-$".".position.y+8
		$Crosshair.visible = true
		$"../../SoundEffekts/Coin".play()
		$throwMolotov.wait_time = $"../..".worm_body.size()/6+2
		$throwMolotov.start()
		print("startet Molotov Timer with wait_time = " + str($throwMolotov.wait_time))

func set_fire():
	$Molotov/Molotov.visible = false
	$Crosshair.visible = false
	
	fire_pos [0]= crosshair_pos+Vector2i(-1,-1)
	fire_pos [1]= crosshair_pos+Vector2i(0,-1)
	fire_pos [2]= crosshair_pos+Vector2i(1,-1)
	fire_pos [3]= crosshair_pos+Vector2i(-1,0)
	fire_pos [4]= crosshair_pos
	fire_pos [5]= crosshair_pos+Vector2i(1,0)
	fire_pos [6]= crosshair_pos+Vector2i(-1,1)
	fire_pos [7]= crosshair_pos+Vector2i(0,1)
	fire_pos [8]= crosshair_pos+Vector2i(1,1)
	print("Fire should spawn around: " + str(crosshair_pos))
	print("Fire will spawn at:")
	for fire in fire_pos.size():
		print(fire_pos[fire])
		
	fire_active = true
	$Burnduration.start()

func draw_fire():
	if fire_active:
		for fire in fire_pos:
			$"../../CharFood/Fire".set_cell(Vector2i(fire.x,fire.y),$"../..".Tile_goup.FIRE,Vector2i(0,0))

func delete_fire():
	var cells = $"../../CharFood/Fire".get_used_cells_by_id($"../..".Tile_goup.FIRE)
	for cell in cells:
		$"../../CharFood/Fire".set_cell(Vector2i(cell.x,cell.y),-1)
	fire_pos = [Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i(),Vector2i()]

func _on_burnduration_timeout() -> void:
	fire_active = false
