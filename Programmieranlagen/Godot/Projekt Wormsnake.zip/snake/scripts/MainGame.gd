extends Node

enum Tile_goup {WORM, FOOD, Potion, CORPSE, FIRE}

var food_pos : Vector2i
var worm_body = [Vector2i(20,10),Vector2i(20,11),Vector2i(20,12)]
var head: Vector2i
var tail: Vector2i

var worm_direction = Vector2i(0,-1)
var add_food = false
var health = 1
var mouth_pos:Vector2i

var hurt_animation = false
var reappear_from: int 
var reappear_at: Vector2i
var escape_dir: Vector2i
var severed_worms = [[Vector2i()],[Vector2i()]]



@onready var stats: Node = $Stats
@onready var game_over_menu: AnimatedSprite2D = $GameOverMenu
@onready var pick_up: Area2D = $CharFood/ItemPickUps/PickUpPosition/PickUp
@onready var brewing_worm_wizard: AnimatedSprite2D = $"Npc's/brewingWormWizard"
@onready var macho_molotov: AnimatedSprite2D = $"Npc's/MachoMolotov"
@onready var hackerworm: AnimatedSprite2D = $"Npc's/Hackerworm"



#programmstartconfig
func _ready() -> void:
	food_pos = place_pickup()
	$CharFood/Food/Foodworm.position.x = food_pos.x * 16 +8
	$CharFood/Food/Foodworm.position.y = food_pos.y * 16 +9
	$CharFood/Food/Foodworm.play("rise")
	hurt_animation = false
	$"Npc's/brewingWormWizard".visible = false
	$"Npc's/brewingWormWizard/floatingPotion".visible = false
	$Timer/Escapetick.paused = true
	$"Npc's/brewingWormWizard".time_per_potion = 60
	$"Npc's/MachoMolotov".visible = false
	$"Npc's/MachoMolotov/Molotov/Molotov".visible = false
	$"Npc's/MachoMolotov/Crosshair".visible = false
	$"Npc's/Airplane".visible = false
	$"Npc's/Hackerworm".visible = false
	$"Npc's/Hackerworm/Talking".visible = false

func _on_game_windup_timeout() -> void:
	$Timer/Gametick.start()

func place_pickup():
	var occupied = $CharFood/Char.get_used_cells()
	var valid = false
	var new_pickup
	while !valid:
		new_pickup = Vector2i((randi() %15 ) + 12,(randi() %17)  + 3)
		valid = true
		for i in occupied.size():
			if new_pickup == occupied[i]:
				valid = false
	return new_pickup

func draw_food():
	$CharFood/Food.set_cell(Vector2i(food_pos.x,food_pos.y),1,Vector2i(0,0))

func draw_worm(chosen_worm):
	var hack_mod_x: int = 0
	var hack_mod_y: int = 0
	for segment_index in chosen_worm.size():
		if $"Npc's/Hackerworm".hack_active == true:
			hack_mod_x = randi()%8
			hack_mod_y = randi()%8
		var segment = chosen_worm[segment_index]
		if segment_on_board(segment):
			#print (str(segment)+"is on board")
			#Kopf
			if segment_index == 0:
				var head_dir = relation2(chosen_worm[0],chosen_worm[1],)
				var chance = randi()%15
				if head_dir == 'left': 
					if chosen_worm[0] != worm_body[0]:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(2,2))
					elif looking_at_food():
						if health == 1:
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(7-hack_mod_x),abs(4-hack_mod_y)))
						elif health == 2:
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(7-hack_mod_x),abs(8-hack_mod_y)))
						$CharFood/Char.set_cell(Vector2i(segment.x-1,segment.y),Tile_goup.WORM,Vector2i(abs(6-hack_mod_x),abs(4-hack_mod_y)))
						mouth_pos = Vector2i(segment.x-1,segment.y)
					elif health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(0-hack_mod_x),abs(2-hack_mod_y)))
					elif health == 2:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(3-hack_mod_x),abs(2-hack_mod_y)))
					elif chance == 3 and health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(1-hack_mod_x),abs(2-hack_mod_y)))
				elif head_dir == 'right':
					if chosen_worm[0] != worm_body[0]:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(2,1))
					elif looking_at_food():
						if health == 1:
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(2-hack_mod_x),abs(5-hack_mod_y)))
						elif health == 2:
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(2-hack_mod_x),abs(9-hack_mod_y)))
						$CharFood/Char.set_cell(Vector2i(segment.x+1,segment.y),Tile_goup.WORM,Vector2i(abs(3-hack_mod_x),abs(9-hack_mod_y)))
						mouth_pos = Vector2i(segment.x+1,segment.y)
					elif health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(0-hack_mod_x),abs(1-hack_mod_y)))
					elif health == 2:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(3-hack_mod_x),abs(1-hack_mod_y)))
					elif chance == 3 and health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(1-hack_mod_x),abs(1-hack_mod_y)))
				elif head_dir == 'up':
					if chosen_worm[0] != worm_body[0]:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(2,0))
					elif looking_at_food():
						if health == 1: 
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(1-hack_mod_x),abs(5-hack_mod_y)))
						elif health == 2:
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(1-hack_mod_x),abs(9-hack_mod_y)))
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y-1),Tile_goup.WORM,Vector2i(abs(1-hack_mod_x),abs(4-hack_mod_y)))
						mouth_pos = Vector2i(segment.x,segment.y-1)
					elif health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(0-hack_mod_x),abs(0-hack_mod_y)))
					elif health == 2:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(3-hack_mod_x),abs(0-hack_mod_y)))
					elif chance == 3 and health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(1-hack_mod_x),abs(0-hack_mod_y)))
				elif head_dir == 'down':
					if chosen_worm[0] != worm_body[0]:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(2,3))
					elif looking_at_food():
						if health == 1: 
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(4-hack_mod_x),abs(6-hack_mod_y)))
						elif health == 2:
							$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(4-hack_mod_x),abs(8-hack_mod_y)))
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y+1),Tile_goup.WORM,Vector2i(abs(4-hack_mod_x),abs(7-hack_mod_y)))
						mouth_pos = Vector2i(segment.x,segment.y+1)
					elif health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(0-hack_mod_x),abs(3-hack_mod_y)))
					elif health == 2:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(3-hack_mod_x),abs(3-hack_mod_y)))
					elif chance == 3 and health == 1:
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(1-hack_mod_x),abs(3-hack_mod_y)))
			#Schwanz
			elif segment_index == chosen_worm.size()-1 :
				var tail_dir = relation2(chosen_worm[-1],chosen_worm[-2])
				if tail_dir == 'left':
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(5-hack_mod_x),abs(1-hack_mod_y)))
				if tail_dir == 'right':
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(5-hack_mod_x),abs(2-hack_mod_y)))
				if tail_dir == 'up':
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(5-hack_mod_x),abs(3-hack_mod_y)))
				if tail_dir == 'down':
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(5-hack_mod_x),abs(0-hack_mod_y)))
			#Körpermitte
			else:
				if hack_mod_y > 3 and $"Npc's/Hackerworm".hack_active == true:
					hack_mod_y = randi()%8
					if hack_mod_y > 3:
						hack_mod_y = randi()%8
				if hack_mod_x < 8 and $"Npc's/Hackerworm".hack_active == true:
					hack_mod_x = randi()%12
					if hack_mod_x < 8:
						hack_mod_x = randi()%12
				var prev_seg = chosen_worm[segment_index+1]-segment
				var next_seg = chosen_worm[segment_index-1]-segment
				#vertikale Linie
				if prev_seg.x == next_seg.x and prev_seg.y < next_seg.y:
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(4-hack_mod_x),abs(2-hack_mod_y)))
				elif prev_seg.x == next_seg.x and prev_seg.y > next_seg.y:
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(4-hack_mod_x),abs(0-hack_mod_y)))
				#horizontale Linie
				elif prev_seg.y == next_seg.y and prev_seg.x < next_seg.x:
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(4-hack_mod_x),abs(1-hack_mod_y)))
				elif prev_seg.y == next_seg.y and prev_seg.x > next_seg.x:
					$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(4-hack_mod_x),abs(3-hack_mod_y)))
				else: 
					if prev_seg.x == -1 and next_seg.y == -1:				#rechts-hoch
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(6-hack_mod_x),abs(1-hack_mod_y)))
					elif prev_seg.x == -1 and next_seg.y == 1:				#rechts-runter
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(7-hack_mod_x),abs(1-hack_mod_y)))
					elif prev_seg.x == 1 and next_seg.y == -1:				#links-hoch
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(7-hack_mod_x),abs(2-hack_mod_y)))
					elif prev_seg.x == 1 and next_seg.y == 1:				#links-runter
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(6-hack_mod_x),abs(2-hack_mod_y)))
					elif prev_seg.y == -1 and next_seg.x == -1:				#runter-links
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(6-hack_mod_x),abs(3-hack_mod_y)))
					elif prev_seg.y == -1 and next_seg.x == 1:				#runter rechts
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(7-hack_mod_x),abs(3-hack_mod_y)))
					elif prev_seg.y == 1 and next_seg.x == -1:				#hoch-links
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(6-hack_mod_x),abs(0-hack_mod_y)))
					elif prev_seg.y == 1 and next_seg.x == 1:				#hoch-rechts
						$CharFood/Char.set_cell(Vector2i(segment.x,segment.y),Tile_goup.WORM,Vector2i(abs(7-hack_mod_x),abs(0-hack_mod_y)))
		else:
			#print (str(segment)+"is not on board")
			pass

func relation2(first_segment:Vector2i,second_segement:Vector2i):
	var segment_relation = second_segement - first_segment
	if segment_relation == Vector2i(-1,0): return 'right'
	if segment_relation == Vector2i(1,0): return 'left'
	if segment_relation == Vector2i(0,1): return 'up'
	if segment_relation == Vector2i(0,-1): return 'down'
	if segment_relation == Vector2i(-1,-1): return 'right-down'
	if segment_relation == Vector2i(1,1): return 'left-up'
	if segment_relation == Vector2i(-1,1): return 'right-up'
	if segment_relation == Vector2i(1,-1): return 'left-down'

func move_worm():
	if add_food == true:
		delete_WORM()
		var body_copy = worm_body.slice(0,worm_body.size())
		var new_head = body_copy[0] + worm_direction
		body_copy.insert(0,new_head)
		worm_body = body_copy
		add_food = false
	else:
		delete_WORM()
		var body_copy = worm_body.slice(0,worm_body.size()-1)
		var new_head: Vector2i
		if hurt_animation: 
			if (worm_direction == Vector2i(1,0) and body_copy[0].x >29) or (worm_direction == Vector2i(-1,0) and body_copy[0].x <10) or (worm_direction == Vector2i(0,1) and body_copy[0].y >22) or (worm_direction == Vector2i(0,-1) and body_copy[0].y <1):
				body_copy[0] = reappear_at - worm_direction*250
				if reappear_from == 0: #up
					worm_direction = Vector2i(0,1)
				elif reappear_from == 1:	#right
					worm_direction = Vector2i(1,0)
				elif reappear_from == 2:	#down
					worm_direction = Vector2i(0,-1)
				elif reappear_from == 3:	#left
					worm_direction = Vector2i(-1,0)

		new_head = body_copy[0] + worm_direction
		body_copy.insert(0,new_head)
		worm_body = body_copy
	#print("I moved")
	head = worm_body[0]
	tail = worm_body[worm_body.size()-1]

func delete_WORM():
	var cells = $CharFood/Char.get_used_cells_by_id(Tile_goup.WORM)
	for cell in cells:
		$CharFood/Char.set_cell(Vector2i(cell.x,cell.y),-1)

func delete_FOOD():
	var cells = $CharFood/Food.get_used_cells_by_id(Tile_goup.FOOD)
	for cell in cells:
		$CharFood/Food.set_cell(Vector2i(cell.x,cell.y),-1)

func delete_CORPSE():
	var cells = $CharFood/Corpse.get_used_cells_by_id(Tile_goup.CORPSE)
	for cell in cells:
		$CharFood/Corpse.set_cell(Vector2i(cell.x,cell.y),-1)

func _input(event):
	#press button
	if !hurt_animation:
		if (Input.is_action_just_pressed("Hoch") or Input.is_action_pressed("Hoch")) and worm_direction !=Vector2i(0,1) and worm_body[1] != worm_body[0]+Vector2i(0,-1): 
			worm_direction = Vector2i(0,-1)
		if (Input.is_action_just_pressed("Runter") or Input.is_action_pressed("Runter")) and worm_direction !=Vector2i(0,-1) and worm_body[1] != worm_body[0]+Vector2i(0,1):  
			worm_direction = Vector2i(0,1)
		if (Input.is_action_just_pressed("Links") or Input.is_action_pressed("Links")) and worm_direction !=Vector2i(1,0) and worm_body[1] != worm_body[0]+Vector2i(-1,0):
			worm_direction = Vector2i(-1,0)
		if (Input.is_action_just_pressed("Rechts") or Input.is_action_pressed("Rechts")) and worm_direction !=Vector2i(-1,0) and worm_body[1] != worm_body[0]+Vector2i(1,0):
			worm_direction = Vector2i(1,0)
	if $GameOverMenu.visible == true:
		if Input.is_action_just_pressed("Reset"):
			reset_game()
		if Input.is_action_just_pressed("ui_cancel"):
			get_tree().quit()

func check_food_eaten():
	if food_pos == worm_body[0]:
		delete_FOOD()
		food_pos = place_pickup()
		stats.incre_foodcount()
		stats.get_player_lenght(worm_body.size())
		$CharFood/Food/Foodworm.position.x = food_pos.x * 16 +8
		$CharFood/Food/Foodworm.position.y = food_pos.y * 16 +9
		$CharFood/Food/Foodworm.play("rise")
		add_food = true
		$SoundEffekts/Eat.play()

func check_potion_eaten():
	if $CharFood/ItemPickUps/PickUpPosition/PickUp.potion_pos == worm_body[0]:
		$CharFood/ItemPickUps/PickUpPosition/PickUp.potion_pos = Vector2i (-5,3)
		health = 2
		$CharFood/ItemPickUps/PickUpPosition/PickUp.draw_potion()
		$SoundEffekts/PowerUp.play()

func check_player_hurt():
	if $"Npc's/MachoMolotov".fire_active:
		print("Ich überprüfe Feuer")
		var index: int = -1
		print("Fire detected at: "+str($"Npc's/MachoMolotov".fire_pos))
		print("worm detected at: "+str(worm_body))
		for segment in worm_body:
			index += 1
			for fire in $"Npc's/MachoMolotov".fire_pos:
				if fire.x == segment.x and fire.y == segment.y:
					print("I hit fire["+str(fire)+"]")
					health-=1
					$SoundEffekts/Hurt.play()
					print("Cut playerBody at: "+ str(segment))
					if index != 0:
						cut_player_body_at(index)
					$Stats.update_score()
					leaving_field()
					hurt_animation = true
					break
			if hurt_animation:
				break

	var head = worm_body[0]
	#leaving playing field
	if (head.x < 12 or head.x > 27 or head.y < 3 or head.y > 20) and !hurt_animation:
		health -= 1
		print("Health redused to"+str(health))
		$SoundEffekts/Hurt.play()
		leaving_field()
	#hitting self
	var index: int = 0
	for segment in worm_body.slice(1,worm_body.size()):
		index+=1
		if segment == head:
			health -=1
			$SoundEffekts/Hurt.play()
			print("Cut playerBody at: "+ str(segment))
			cut_player_body_at(index+1)
			print("Health redused to"+str(health))
			stats.get_player_lenght(worm_body.size())
			leaving_field()

func cut_player_body_at(index):
	var new_severed_worm = worm_body.slice(index,worm_body.size())
	worm_body = worm_body.slice(0,index-1)
	
	if new_severed_worm.size() > 3:
		print("severed worm got an entry")
		severed_worms.insert(0,new_severed_worm)
	
	#for segment in severed_worm:
		#$CharFood/Corpse.set_cell(Vector2i(segment.x,segment.y),Tile_goup.CORPSE,Vector2i(2,0))

func leaving_field():
	if health <= 0:
		game_over()
	else:
		$Timer/Gametick.paused = true
		print("Gametick pausiert")
		reappear_from = randi() %4
		hurt_animation = true
		if reappear_from == 0:	#up
			reappear_at = Vector2i((randi() %15 ) + 12,1)
		elif reappear_from == 1:	#right
			reappear_at = Vector2i(29,(randi() %17)  + 3)
		elif reappear_from == 2:	#down
			reappear_at = Vector2i((randi() %15 ) + 12,21)
		elif reappear_from == 3:	#left
			reappear_at = Vector2i(10,(randi() %17)  + 3)
		stats.update_score()
		$Timer/Escapetick.paused = false

func segment_on_board(segment): #returns: bool
	var gone = true
	if segment.x <30 and segment.x >9 and segment.y >0 and segment.y <22:
		gone = false
	return !gone

func game_over(): #stop the game
	$Timer/Gametick.stop()
	$Stats/Gametimer.stop()
	$MusikTheme.stop()
	$GameOverMenu.visible = true
	stats.reset_score()
	print("GameOverMenu should be visible")

func reset_game(): 
	$Timer/GameWindup.start()
	$Stats/Gametimer.start()
	$GameOverMenu.visible = false
	delete_WORM()
	delete_CORPSE()
	worm_body = [Vector2i(20,10),Vector2i(20,11),Vector2i(20,12)]
	worm_direction = Vector2i(1,0)
	health = 1
	draw_worm(worm_body)
	$"Npc's/brewingWormWizard".visible = false
	$"Npc's/brewingWormWizard/floatingPotion".visible = false
	$"Npc's/brewingWormWizard/floatingPotion".position = Vector2i(12,-14)
	$"Npc's/MachoMolotov".delete_fire()
	$"Npc's/MachoMolotov".visible = false
	$"Npc's/MachoMolotov/Molotov".visible = false
	$"Npc's/MachoMolotov/Crosshair".visible = false
	$"Npc's/MachoMolotov/Burnduration".stop()
	$"Npc's/MachoMolotov/throwMolotov".stop()
	$"Npc's/MachoMolotov/Molotov".being_thrown = false
	$"Npc's/Airplane".airplane_rdy = false
	$"Npc's/Airplane".airplane_destroyed = false
	$Crowd.clear_crowd()
	$MusikTheme.play()

func _on_gametick_timeout():
	move_worm()
	draw_food()
	draw_worm(worm_body)
	for severed_worm in severed_worms:
		draw_worm(severed_worm)
	check_food_eaten()
	check_potion_eaten()
	if not ($GameOverMenu.visible or hurt_animation) :
		check_player_hurt()

func _on_escapetick_timeout():
	print("Escapetick is running")
	if !segment_on_board(tail):
		print("Escapetick stops now")
		$Timer/Escapetick.paused = true
		enter_field()
	else:
		move_worm()
		draw_food()
		draw_worm(worm_body)
		for severed_worm in severed_worms:
			draw_worm(severed_worm)
		check_food_eaten()

func enter_field():
	print("initialize enter_field")
	while !segment_on_board(worm_body[0]):
		move_worm()
	move_worm()
	hurt_animation = false
	print("I reentered the field at "+ str(worm_body[0]))
	health = 1
	$Timer/Gametick.paused = false
	$"Npc's/MachoMolotov".delete_fire()

func _process(delta):
	pass

func looking_at_food() -> bool:
	var food_pos: Vector2i = $CharFood/Food.get_used_cells() [0]
	if worm_direction == Vector2i(0,-1) and food_pos.x == worm_body[0].x and food_pos.y < worm_body[0].y:
		return true 
	elif worm_direction == Vector2i(0,1) and food_pos.x == worm_body[0].x and food_pos.y > worm_body[0].y:
		return true
	elif worm_direction == Vector2i(-1,0) and food_pos.y == worm_body[0].y and food_pos.x < worm_body[0].x:
		return true
	elif worm_direction == Vector2i(1,0) and food_pos.y == worm_body[0].y and food_pos.x > worm_body[0].x:
		return true
	elif  food_pos.distance_to(worm_body[0]) < 3:
		return true
	else: 
		return false

func _on_foodworm_animation_finished() -> void:
	$CharFood/Food/Foodworm.play("idle")

func _on_musik_theme_finished() -> void:
	$MusikTheme.play()
