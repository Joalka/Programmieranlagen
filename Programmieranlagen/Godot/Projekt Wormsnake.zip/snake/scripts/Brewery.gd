extends AnimatedSprite2D

@onready var stats: Node = $"../../Stats"
@onready var pick_up: Area2D = $"../../CharFood/ItemPickUps/PickUpPosition/PickUp"
@onready var main_game: Node = $"../.."

var time_per_potion: int = 60 #in Sekunden
var luck_check: int = 1

func _on_gametick_timeout() -> void:
	brewing()

func brewing():
	#print("wizard is brewing")
	if $".".visible == true and randi() %(time_per_potion*4) == luck_check:
		$floatingPotion.visible = true
		$"../../SoundEffekts/PowerUp".play()
		luck_check = -5
	if $"../..".health <2 and $floatingPotion.visible == true and $throwpotion.is_stopped()==true:
		print("PotionthrowTimer started")
		$throwpotion.start()
