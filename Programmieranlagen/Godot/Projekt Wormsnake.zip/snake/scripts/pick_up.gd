extends Area2D
@onready var brewing_worm_wizard: AnimatedSprite2D = $"../../../Npc's/brewingWormWizard"
@onready var floating_potion: AnimatedSprite2D = $"../../../../Npc's/brewingWormWizard/floatingPotion"
var potion_pos = Vector2i (-5,3) #Grid Coordinaten

func _on_throwpotion_timeout() -> void:
	print("Wirf Potion!")
	potion_pos = $"../../../..".place_pickup()
	draw_potion()
	$PotionAnimation.play("Potion fällt runter")
	$"../../../../Npc's/brewingWormWizard/floatingPotion".visible = false
	$"../../../../Npc's/brewingWormWizard".luck_check = 1

func draw_potion():
	$"..".position = potion_pos*16
